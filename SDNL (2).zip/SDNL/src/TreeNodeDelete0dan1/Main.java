 package TreeNodeDelete0dan1;
public class Main {

    public static void main(String[] args) {
        Tree sc = new Tree();
        sc.insertNode(42);
        sc.insertNode(21);
        sc.insertNode(38);
        sc.insertNode(27);
        sc.insertNode(71);
        sc.insertNode(82);
        sc.insertNode(55);
        sc.insertNode(63);
        sc.insertNode(6);
        sc.insertNode(2);
        sc.insertNode(40);
        sc.insertNode(12);

        System.out.println("Root: " + sc.root.getData());
        System.out.println(" Data sebelum dihapus");
        System.out.println("--> Preorder");
        sc.preorderTraversal();
        System.out.println("");
        System.out.println("--> Inorder");
        sc.inorderTraversal();
        System.out.println("");
        System.out.println("--> Postorder");
        sc.postorderTraversal();

        sc.delete(12);
        sc.delete(27);
        sc.delete(6);
        sc.delete(55);

        System.out.println("\n");
        System.out.println("Data sesudah dihapus");
        System.out.println("--> Preorder");
        sc.preorderTraversal();
        System.out.println("");
        System.out.println("--> Inorder");
        sc.inorderTraversal();
        System.out.println("");
        System.out.println("--> Postorder");
        sc.postorderTraversal();
    }
}
