package Modul8;

public class Graph {

    private int maxVertex = 10;
    private Vertex[] vertexList;
    private int[][] adjacencyMatrix;
    private int countVertex = 0;

    public Graph() {
        vertexList = new Vertex[maxVertex];
        adjacencyMatrix = new int[maxVertex][maxVertex];

        for (int i = 0; i < maxVertex; i++) {
            for (int j = 0; j < maxVertex; j++) {

                if (i == j) {
                    adjacencyMatrix[i][j] = 0;
                }
            }
        }
    }

    public void addVertex(char label) {
        if (countVertex < maxVertex) {
            vertexList[countVertex] = new Vertex(label);
            countVertex++;
        }
    }
    
    public void addEdge(int satu, int dua, int value){
        adjacencyMatrix[satu] [dua] = value;
        adjacencyMatrix[dua] [satu] = value;
    }
    
    public void addEdge(char satu, char dua, int value){
        adjacencyMatrix[indexVertex(satu)][indexVertex(dua)] = value;
        adjacencyMatrix[indexVertex(dua)][indexVertex(satu)] = value;
    }

    private int indexVertex(char index){
        for (int i = 0; i < vertexList.length; i++) {
            if (vertexList[i].getLabel() == index) {
                return i;
            }
        }
        return -0;
    }

    @Override
    public String toString() {
        return "Graph{" + "maxVertex=" + maxVertex + ", vertexList=" 
                + vertexList 
                + ", adjacencyMatrix=" + adjacencyMatrix + ", countVertex=" 
                + countVertex + '}';
    }
    
    public void show(){
        for (int i = 0; i < vertexList.length; i++) {
            for (int j = 0; j < vertexList.length; j++) {
                if (adjacencyMatrix[i][j] != 0) {
                    System.out.println(vertexList[i].getLabel()
                            + " terhubung dengan "
                            +vertexList[j].getLabel()+ " dengan bobot " 
                            + adjacencyMatrix[i][j]);
                }
            }
        }
    }
    
//    public void showGraph() {
//        for (int i = 0; i < countVertex; i++) {
//            for (int k = 0; k < countVertex; k++) {
//                System.out.println(adjacencyMatrix[i][k] + " ");
//            }
//            System.out.println("\n");
//        }
//    }
}
