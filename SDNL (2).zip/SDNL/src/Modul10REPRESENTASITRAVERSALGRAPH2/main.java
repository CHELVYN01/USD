package Modul10REPRESENTASITRAVERSALGRAPH2;




public class main {

    public static void main(String[] args) {
        Graph g = new Graph();
        
        //memasukan variabel vertex
        g.addVertex('A');
        g.addVertex('B');
        g.addVertex('C');
        g.addVertex('D');
        g.addVertex('F');
        g.addVertex('G');
        g.addVertex('H');
        
        // masukan nilai atau bobot antar dua vertex
        g.addEdge('A', 'B', 5);
        g.addEdge('A', 'D', 7);
        g.addEdge('A', 'F', 4);
        g.addEdge('B', 'C', 7);
        g.addEdge('B', 'D', 6);
        g.addEdge('C', 'D', 6);
        g.addEdge('C', 'G', 9);
        g.addEdge('C', 'H', 15);
        g.addEdge('D', 'G', 5);
        g.addEdge('F', 'G', 9);
        g.addEdge('G', 'H', 8);
        
        //menampilkan adjecency Matrix
        System.out.println("");
        System.out.println("Adjecency Matrix :\n");
        g.toString();
        
        System.out.println("");
        g.show();
        
        // menampilkan kunjungan dfs
        System.out.println("");
        System.out.println("Hasil DFS");
        g.dfs();
        
        System.out.println("\n");
        // menampilkan kunjungan bfs
        System.out.println("Hasil BFS");
        g.bfs();
        System.out.println("");
        
    }
}
