package TreeNode2_Travel;

public class Main {

    public static void main(String[] args) {
        Tree obj = new Tree();

        obj.insert(42);
        obj.insert(21);
        obj.insert(38);
        obj.insert(27);
        obj.insert(71);
        obj.insert(82);
        obj.insert(55);
        obj.insert(63);
        obj.insert(6);
        obj.insert(2);
        obj.insert(40);
        obj.insert(12);

        
        System.out.println("Binary Search");
        System.out.println("==============");
        System.out.println("ROOT = "+obj.getRoot().getData());
        System.out.println("\n");
        System.out.println("In Order: ");
        obj.inorderTraversal();
        System.out.println();
        System.out.println("\nPre Order: ");
        obj.preorderTraversal();
        System.out.println();
        System.out.println("\nPost Order: ");
        obj.postorderTraversal();
        System.out.println("\n");
        obj.find(6);
        System.out.println();
        obj.find(1);
        obj.height(42);

    }
}
