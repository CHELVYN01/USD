package TreeNode2_Travel;

public class Tree {

    private TreeNode root;

    public Tree() {
    }

    public Tree(TreeNode node) {
        this.root = root;
    }

    public void insert(int data) {
        TreeNode temp = new TreeNode(data);
        if (root == null) {
            root = temp;
        } else {
            TreeNode click = root;
            while (true) {
                if (temp.getData() <= click.getData()) {
                    if (click.getLeftNode() == null) {
                        click.setLeftNode(temp);
                        return;
                    } else {
                        click = click.getLeftNode();
                    }
                } else {
                    if (click.getRightNode() == null) {
                        click.setRightNode(temp);
                        return;
                    } else {
                        click = click.getRightNode();
                    }
                }
            }
        }
    }

    public TreeNode find(int cari) {
        TreeNode bantu = root;
        while (bantu != null) {
            if (bantu.getData() == cari) {
                System.out.println("Data yang anda cari: " + cari);
                System.out.println("Ditemukan");
                return bantu;
            } else {
                if (bantu.getData() <= cari) {
                    bantu = bantu.getRightNode();
                } else {
                    bantu = bantu.getLeftNode();
                }
            }
        }
        System.out.println("Data yang anda cari: " + cari);
        System.out.println("Tidak ditemukan");
        return bantu;
    }

    public TreeNode getRoot() {
        return root;
    }

    public void setRoot(TreeNode node) {
        this.root = root;
    }

    public void inOrderHelper(TreeNode data) {
        if (data != null) {
            inOrderHelper(data.getLeftNode());
            System.out.print(data.getData() + " ");
            inOrderHelper(data.getRightNode());
        }
    }

    public void preOrderHelper(TreeNode data) {
        if (data != null) {
            System.out.print(data.getData() + " ");
            preOrderHelper(data.getLeftNode());
            preOrderHelper(data.getRightNode());
        }
    }

    public void postOrderHelper(TreeNode data) {
        if (data != null) {
            postOrderHelper(data.getLeftNode());
            postOrderHelper(data.getRightNode());
            System.out.print(data.getData() + " ");
        }
    }

    public void inorderTraversal() {
        inOrderHelper(root);
    }

    public void preorderTraversal() {
        preOrderHelper(root);
    }

    public void postorderTraversal() {
        postOrderHelper(root);
    }

    public void height(int data) {
        TreeNode bantu = root;
        int high = 1;
        if (root != null) {
            while (bantu != null) {
                if (data == bantu.getData()) {
                    high = high + 1;
                    System.out.println("Height " + data + " : " + high);

                    break;
                } else if (data > bantu.getData()) {
                    bantu = bantu.getRightNode();
                    high = high + 1;
                } else {
                    bantu = bantu.getLeftNode();
                    high = high + 1;
                }
            }
        }
    }
  
      
}
