package TreeNodeDelete2anak;

public class Tree {

    TreeNode root;

    public Tree() {

    }

    public Tree(TreeNode root) {
        this.root = root;
    }

    public void insert(int data) {
        TreeNode baru = new TreeNode(data);
        TreeNode bantu = root;
        if (root == null) {
            root = baru;
        } else {
            while (bantu != null) {
                if (baru.getData() > bantu.getData()) {
                    if (bantu.getRightNode() == null) {
                        bantu.setRightNode(baru);
                        baru.setParent(bantu);
                        break;
                    } else {
                        bantu = bantu.getRightNode();
                    }
                }
                if (baru.getData() <= bantu.getData()) {
                    if (bantu.getLeftNode() == null) {
                        bantu.setLeftNode(baru);
                        baru.setParent(bantu);
                        break;
                    } else {
                        bantu = bantu.getLeftNode();
                    }
                }
            }
        }
    }

    public boolean delete(int data) {
        TreeNode temp = getCurrent(data);
        boolean tampung = false;

        if (temp == null) {
            return true;
        } else {
            if (temp.getLeftNode() == null && temp.getRightNode() == null) {
                return tampung = deleteHelper0(temp);
            } else if (temp.getLeftNode() == null || temp.getRightNode() == null) {
                return tampung = deleteHelper1(temp);
            } else {
                return tampung = deleteHelper2(data);
            }
        }

    }

    public boolean deleteHelper0(TreeNode node) {
        TreeNode parent = node.getParent();
        if (parent.getRightNode() == node) {
            parent.setRightNode(null);
            return true;
        } else {
            parent.setLeftNode(null);
            return true;
        }
    }

    public boolean deleteHelper1(TreeNode node) {
        TreeNode parent = node.getParent();
        if (parent.getRightNode() == node) {
            if (node.getLeftNode() == null) {
                parent.setRightNode(node.getRightNode());
                node.getRightNode().setParent(parent);
                return true;
            } else {
                parent.setRightNode(node.getRightNode());
                node.getLeftNode().setParent(parent);
                return true;
            }
        } else {
            if (node.getLeftNode() == null) {
                parent.setLeftNode(node.getRightNode());
                node.getRightNode().setParent(parent);
                return true;
            } else {
                parent.setLeftNode(node.getLeftNode());
                node.getLeftNode().setParent(parent);
                return true;
            }
        }
    }

    public TreeNode getCurrent(int data) {
        return search(data);
    }

    public boolean deleteHelper2(int data) {
        TreeNode bantu = getCurrent(data);
        TreeNode predeccessor = getPredecessor(bantu);
        TreeNode indukPrede = getPredecessor(root);
        bantu.setData(predeccessor.getData());

        if (indukPrede != bantu) {
            if (predeccessor.getLeftNode() != null) {
                indukPrede.setRightNode(predeccessor.getLeftNode());
            } else {
                indukPrede.setRightNode(null);
            }
        } else {
            if (predeccessor.getLeftNode() != null) {
                bantu.setLeftNode(predeccessor.getLeftNode());
            } else {
                bantu.setLeftNode(null);
            }
        }
        return true;
    }

    public TreeNode search(int data) {
        TreeNode bantu = root;

        if (root == null) {
            return null;
        } else {
            while (bantu != null) {
                if (data == bantu.getData()) {
                    return bantu;
                } else {
                    if (data > bantu.getData()) {
                        bantu = bantu.getRightNode();
                    } else {
                        bantu = bantu.getLeftNode();
                    }
                }
            }
        }
        return null;
    }

    public TreeNode getRoot() {
        return root;
    }

    public void setRoot(TreeNode root) {
        this.root = root;
    }

    public void preorderTraversal() {
        preorderHelper(getRoot());
    }

    public void inorderTraversal() {
        inorderHelper(getRoot());
    }

    public void postorderTraversal() {
        postorderHelper(getRoot());
    }

    public void preorderHelper(TreeNode root) {
//        1. Cetak isi simpul yang dikunjungi.
        if (root != null) {
            System.out.print(root.getData() + " ");
//        2. Kunjungi cabang kiri.      
            preorderHelper(root.getLeftNode());
//        3. Kunjungi cabang kanan            
            preorderHelper(root.getRightNode());
        }

    }

    public void inorderHelper(TreeNode root) {
        if (root != null) {
            inorderHelper(root.getLeftNode());
            System.out.print(root.getData() + " ");
            inorderHelper(root.getRightNode());
        }

    }

    public void postorderHelper(TreeNode root) {
        if (root != null) {
            postorderHelper(root.getLeftNode());
            postorderHelper(root.getRightNode());
            System.out.print(root.getData() + " ");
        }
    }

    public TreeNode leaf() {
        int jumlah = leafHelp(root);
        if (root == null) {
            System.out.println("Tree Masih Kosong");
        } else {
            System.out.println("Jumlah Leaf adalah : " + jumlah);
        }
        return null;
    }

    public int leafHelp(TreeNode root) {
        if (root == null) {
            return 0;
        }
        if (root.getLeftNode() == null && root.getRightNode() == null) {
            System.out.println("Leaf : " + root.getData() + " ");
            return 1;
        } else {
            return leafHelp(root.getLeftNode()) + leafHelp(root.getRightNode());
        }
    }

    public TreeNode getPredecessor(TreeNode node) {
        TreeNode a = node.getLeftNode();
        if (node.getRightNode() != null) {
            a = a.getRightNode();
        }
        return a;
    }

}
