/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TreeNodeDelete2anak;

/**
 *
 * @author HP
 */
public class TreeNode {
   
 
     private int data;
    private TreeNode leftNode;
    private TreeNode rightNode;
    private TreeNode parent;

    public TreeNode() {

    }

    public TreeNode(int data) {
        this.data = data;
    }

    public TreeNode(int data, TreeNode parent) {
        this.data = data;
        this.parent = parent;
        leftNode = rightNode = null;
    }

    public void insert(int data) {

    }

    public int getData() {
        return data;
    }

    public void setData(int data) {

    }

    public TreeNode getLeftNode() {
        return leftNode;
    }

    public void setLeftNode(TreeNode leftNode) {
        this.leftNode = leftNode;
    }

    public TreeNode getRightNode() {
        return rightNode;
    }

    public void setRightNode(TreeNode rightNode) {
        this.rightNode = rightNode;
    }

    public TreeNode getParent() {
        return parent;
    }

    public void setParent(TreeNode parent) {
        this.parent = parent;
    }
   }
