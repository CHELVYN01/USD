/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TreeNodeDelete2anak;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        Tree obj = new Tree();

         Tree sc = new Tree();
        sc.insert(42);
        sc.insert(21);
        sc.insert(38);
        sc.insert(27);
        sc.insert(71);
        sc.insert(82);
        sc.insert(55);
        sc.insert(63);
        sc.insert(6);
        sc.insert(2);
        sc.insert(40);
        sc.insert(12);

        System.out.println("Root: " + sc.root.getData());
        System.out.println(" Data sebelum dihapus");
        System.out.println("--> Preorder");
        sc.preorderTraversal();
        System.out.println("");
        System.out.println("--> Inorder");
        sc.inorderTraversal();
        System.out.println("");
        System.out.println("--> Postorder");
        sc.postorderTraversal();

        sc.delete(42);
        sc.delete(27);
        

        System.out.println("\n");
        System.out.println("Data sesudah dihapus");
        System.out.println("--> Preorder");
        sc.preorderTraversal();
        System.out.println("");
        System.out.println("--> Inorder");
        sc.inorderTraversal();
        System.out.println("");
        System.out.println("--> Postorder");
        sc.postorderTraversal();
    }
}
