/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan.pkg6;

/**
 *
 * @author lomop
 */
public class Pertemuan6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tree tree1 = new Tree();

        tree1.insertRek(42);
        tree1.insertRek(21);
        tree1.insertRek(38);
        tree1.insertRek(27);
        tree1.insertRek(71);
        tree1.insertRek(82);
        tree1.insertRek(55);
        tree1.insertRek(63);
        tree1.insertRek(6);
        tree1.insertRek(2);
        tree1.insertRek(40);
        tree1.insertRek(12);

        tree1.Delete(42);
        System.out.println(tree1.getRoot().getData());
        tree1.Delete(21);
        tree1.Delete(38);
        tree1.Delete(27);
        tree1.Delete(71);
        tree1.Delete(82);
        tree1.Delete(55);
        tree1.Delete(63);
        tree1.Delete(6);
        tree1.Delete(2);
        tree1.Delete(40);
        tree1.Delete(12);
        tree1.PreOrderTraversal();
    }

}
