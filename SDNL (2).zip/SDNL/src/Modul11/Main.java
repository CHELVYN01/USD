package Modul11;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Graph g = new Graph();
        g.addVertex('A');
        g.addVertex('B');
        g.addVertex('C');
        g.addVertex('D');
        g.addVertex('E');
        g.addVertex('F');
        g.addVertex('G');
        g.addVertex('H');
        g.addVertex('I');
        g.addVertex('J');

        g.addEdge('A', 'B', 5);
        g.addEdge('A', 'C', 5);
        g.addEdge('B', 'D', 4);
        g.addEdge('B', 'E', 9);
        g.addEdge('C', 'D', 4);
        g.addEdge('C', 'F', 7);
        g.addEdge('D', 'E', 8);
        g.addEdge('D', 'F', 6);
        g.addEdge('E', 'F', 10);
        g.addEdge('E', 'G', 10);
        g.addEdge('E', 'H', 8);
        g.addEdge('E', 'I', 9);
        g.addEdge('F', 'G', 3);
        g.addEdge('G', 'H', 6);
        g.addEdge('G', 'J', 7);
        g.addEdge('H', 'I', 4);
        g.addEdge('H', 'J', 6);
        g.addEdge('I', 'J', 7);

        System.out.println("Minimum Spanning Tree");
        System.out.println("Keterangan\t :");
        System.out.println("Index 0\t = A");
        System.out.println("Index 1\t = B");
        System.out.println("Index 2\t = C");
        System.out.println("Index 3\t = D");
        System.out.println("Index 4\t = E");
        System.out.println("Index 5\t = F");
        System.out.println("Index 6\t = G");
        System.out.println("Index 7\t = H");
        System.out.println("Index 8\t = I");
        System.out.println("Index 9\t = J\n");

        System.out.println("Matriks Adjency");
        g.toString();
        System.out.println("");
        g.show();

        System.out.println("DFS");
        g.dfs();
        System.out.println("");
        System.out.println("BFS");
        g.bfs();
        System.out.println("");
        System.out.println("Algoritma Prim");

        ArrayList<Edge> ed = g.getPrimEdgeu();
        for (int i = 0; i < ed.size(); i++) {
            System.out.println(ed.get(i).toString());
        }
        System.out.println("");
        int total = 0;
        for (int i = 0; i < ed.size(); i++) {
            total += ed.get(i).getWeight();
        }
        System.out.println("Total Jarak Terpendek\t: " + total);
        System.out.println("");

    }
}
