package Modul11;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Graph {
    private int maxVertex = 10;
    private Vertex[] vertexList;
    private int[][] adjacencyMatrix;
    private int countVertex = 0;

    public Graph() {
        vertexList = new Vertex[maxVertex];
        adjacencyMatrix = new int[maxVertex][maxVertex];

        for (int i = 0; i < maxVertex; i++) {
            for (int j = 0; j < maxVertex; j++) {

                if (i == j) {
                    adjacencyMatrix[i][j] = 0;
                } else {
                    adjacencyMatrix[i][j] = 0;
                }
            }
        }
    }

    public void addVertex(char v) {
        vertexList[countVertex++] = new Vertex(v);
    }

    public void addEdge(char vertexA, char vertexB, int weight){
        Edge edge = new Edge (indexVertex(vertexA), indexVertex(vertexB), weight);
        adjacencyMatrix[edge.getVertexA()][edge.getVertexB()] = edge.getWeight();
        adjacencyMatrix[edge.getVertexB()][edge.getVertexA()] = edge.getWeight();
    }

    private int indexVertex(char index) {
        for (int i = 0; i < countVertex; i++) {
            if (vertexList[i].label == index) {
                return i;
            }
        }
        return -1;
    }

    public void dfs() {
        int seed = 0;
        Stack stck = new Stack();
        stck.push(seed);
        while (!stck.isEmpty()) {
            int bantu = (int) stck.pop();
            if (!vertexList[bantu].flagVisited == true) {
                System.out.print(vertexList[bantu].label + " ");
                vertexList[bantu].flagVisited = true;
            }
                for (int i = countVertex -1; i >= 0; i--) {
                    if (adjacencyMatrix[bantu][i] >= 1 && !vertexList[i].flagVisited) {
                        stck.add(i);
                    }
                }
            }
             for (int i = 0; i <= countVertex -1; i++) {
                vertexList[i].flagVisited = false;
            
        }
    }

    public void bfs() {
        int seed = 0;
        Queue queue = new LinkedList();
        queue.add(seed);
        while (!queue.isEmpty()) {
            int bantu = (int) queue.remove();
            if (!vertexList[bantu].flagVisited == true) {
                System.out.print(vertexList[bantu].label + " ");
                vertexList[bantu].flagVisited = true;
                for (int i = 0 ; i <= countVertex -1 ; i++) {
                    if (adjacencyMatrix[bantu][i] >= 1 && !vertexList[i].flagVisited) {
                        queue.add(i);
                    }
                }
            }
        
        }for (int i = 0; i <= countVertex - 1; i++) {
            vertexList[i].flagVisited = false;
        }
    }
    public void show() {
        for (int i = 0; i < countVertex; i++) {
            for (int j = 0; j < countVertex; j++) {
                if (adjacencyMatrix[i][j] != 0 && adjacencyMatrix [i] [j] != -1) {
                    System.out.println(vertexList[i].label
                            + " Terhubung ke " + vertexList[j].label
                            + " Dengan Beban " + adjacencyMatrix [i][j] );
                }
            }
            System.out.println("");
        }
    }

    @Override
    public String toString() {
        String hasil = " ";
        for (int i = 0; i < countVertex; i++){
            for (int j = 0; j < countVertex; j++){
                System.out.printf(adjacencyMatrix[i][j] + "\t\t");
            }
            System.out.println("");
        }
        return hasil;
    }
    
        public ArrayList<Edge> getPrimEdgeu() {
        ArrayList<Edge> primEdges = new ArrayList<>();
        ArrayList<Integer> primVertexs = new ArrayList<>();
        int seed = 0;
        primVertexs.add(seed);
        vertexList[seed].flagVisited = true;
        while (primVertexs.size() < vertexList.length) {
            int tempMinWeight = Integer.MAX_VALUE;
            int tempMinIndekVertexI = -1;
            int tempMinIndekVertexJ = -1;
            for (int i = 0; i < primVertexs.size(); i++) {
                for (int j = 0; j < vertexList.length; j++) {
                    if (adjacencyMatrix[primVertexs.get(i)][j] > 0 && !vertexList[j].flagVisited
                            && adjacencyMatrix[primVertexs.get(i)][j] < tempMinWeight) {
                        tempMinWeight = adjacencyMatrix[primVertexs.get(i)][j];
                        tempMinIndekVertexI = primVertexs.get(i);
                        tempMinIndekVertexJ = j;
                    }
                }
            }
            primVertexs.add(tempMinIndekVertexJ);
            vertexList[tempMinIndekVertexJ].flagVisited = true;
            primEdges.add(new Edge(tempMinIndekVertexI, tempMinIndekVertexJ, tempMinWeight));

        }
        return primEdges;
        
        
    }
        
    
}


