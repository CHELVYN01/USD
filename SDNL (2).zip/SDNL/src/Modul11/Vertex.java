package Modul11;

public class Vertex {
 char label;
    boolean flagVisited;

    public Vertex(char label) {
        this.label = label;

        
    }
}


