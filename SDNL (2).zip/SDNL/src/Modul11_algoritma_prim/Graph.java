package Modul11_algoritma_prim;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Graph {

    Vertex[] vertexList;
    int[][] adjMat;
    int maxVertex;
    int countVertex = 0;

    public Graph(int jumV) {
        this.maxVertex = jumV;
        vertexList = new Vertex[jumV];
        adjMat = new int[jumV][jumV];
        //perintah unutuk mengisi nilai atribut jumV
        for (int i = 0; i < jumV; i++) {
            for (int j = 0; j < jumV; j++) {
                if (i == j) {
                    adjMat[i][j] = 0;
                } else {
                    adjMat[i][j] = -1;
                }
            }
        }
    }

    public void addVertex(String isi) {
        if (countVertex < maxVertex) { // jika counVertex lebih kecil dari maxVertex
            Vertex node = new Vertex(isi);
            vertexList[countVertex] = node;
            countVertex++;
        } else {
            System.out.println("Vertex sudah mencapai jumlah max");
            // untuk menampilkan tulisan Vertex sudah mencapai jumlah max pada output
        }
    }

    public int getVertex(String isi) {
        for (int i = 0; i < vertexList.length; i++) {
            if (vertexList[i].getLabel().equals(isi)) {
                return i;

            }
        }
        return -1;
    }

    public void addEdge(String a, String b, int w) {// method untuk edge a,b dan w
        adjMat[getVertex(a)][getVertex(b)] = w;
        adjMat[getVertex(b)][getVertex(a)] = w;
    }

    public void displayVertex(int data) {
        if (data < countVertex) {
            System.out.println(vertexList[data].getLabel());

        } else {
            System.out.println("tidak ada vertex ke-" + data);

        }

    }

    public void DisplayVertex(String a) {
        int tampung = getVertex(a);
        System.out.println(vertexList[tampung].getLabel());
    }

    public void tampilMatrix() {

        for (int i = 0; i < countVertex; i++) {
            for (int j = 0; j < maxVertex; j++) {
                System.out.print(adjMat[i][j]);
            }

        }

        {

        }
    }

    public void DFS() {
        Stack<Integer> stack = new Stack<Integer>();
        int seed = 0;
        stack.push(seed);

        while (!stack.isEmpty()) {
            int bantu = stack.pop();
            if (vertexList[bantu].isVisited() == false) {
                System.out.print(vertexList[bantu].getLabel() + " ");
                vertexList[bantu].setVisited(true);

                for (int i = countVertex - 1; i > 0; i--) {
                    if (adjMat[bantu][i] > 0 && vertexList[i].isVisited() == false) {
                        stack.push(i);
                    }
                }
            }
        }
        resetVisited();
    }

    public void BFS() {
        Queue<Integer> queue = new LinkedList<Integer>();
        int seed = 0;
        queue.add(seed);

        while (!queue.isEmpty()) {
            int bantu = queue.remove();
            if (vertexList[bantu].isVisited() == false) {
                System.out.print(vertexList[bantu].getLabel() + " ");
                vertexList[bantu].setVisited(true);
                for (int i = 0; i < countVertex; i++) {
                    if (adjMat[bantu][i] > 0 && vertexList[i].isVisited() == false) {
                        queue.add(i);
                    }
                }
            }
        }
        resetVisited();
    }

    public void resetVisited() {// method untuk resetVisited
        for (int i = 0; i < maxVertex; i++) {
            vertexList[i].setVisited(false);
        }
    }

    public ArrayList<Edge> mst() {
        ArrayList<Edge> mst = new ArrayList<Edge>();//tipe dinamis, bisa ditambah sizenya
        ArrayList<Integer> primVertex = new ArrayList<Integer>();
        primVertex.add(0);
        vertexList[0].wasVisited = true;
        while (primVertex.size() < countVertex) {
            int minWeight = Integer.MAX_VALUE;
            int minIndexVertexI = -1;
            int minIndexVertexJ = -1;
            for (int i = 0; i < primVertex.size(); i++) {
                for (int j = 0; j < countVertex; j++) {
                    if (adjMat[primVertex.get(i)][j] > 0 && vertexList[j].wasVisited == false && adjMat[primVertex.get(i)][j] < minWeight) {
                        minWeight = adjMat[primVertex.get(i)][j];
                        minIndexVertexI = primVertex.get(i);
                        minIndexVertexJ = j;
                    }
                }
            }
            primVertex.add(minIndexVertexJ);
            vertexList[minIndexVertexJ].wasVisited = true;
            mst.add(new Edge(minWeight, vertexList[minIndexVertexI], vertexList[minIndexVertexJ]));
        }
        resetVisited();
        return mst;
    }
         public void show() {
        for (int i = 0; i < countVertex; i++) {
            for (int j = 0; j < countVertex; j++) {
                if (adjMat[i][j] != 0 && adjMat[i][j] != -1) {
                    System.out.println(vertexList[i].label + " terhubung ke "
                            + vertexList[j].label + "dengan bobot ="
                            + adjMat[i][j]);
                }
            }
            System.out.println("");
        }
    }
          public String toString() {
        String read = "";
        for (int i = 0; i < countVertex; i++) {
            for (int j = 0; j < countVertex; j++) {
                System.out.print(adjMat[i][j] + "\t");
            }
            System.out.println("");
        }
        return read;
    }
    }

