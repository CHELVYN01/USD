package Modul11_algoritma_prim;

public class Edge {

    int bobot;
    Vertex vertexA, vertexB;

    public Edge() {

    }

    public Edge(int bobot, Vertex vertexA, Vertex vertexB) {
        this.bobot = bobot;
        this.vertexA = vertexA;
        this.vertexB = vertexB;
    }

    public Edge(Vertex vertexA, Vertex vertexB) {
        this.vertexA = vertexA;
        this.vertexB = vertexB;
    }

    public Edge(int minIndexVertexI, int minIndexVertexJ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Edge(int minWeight) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Edge(int minWeight, int minIndexVertexI, int minIndexVertexJ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getBobot() {
        return bobot;
    }

    public void setBobot(int bobot) {
        this.bobot = bobot;
    }

    public Vertex getVertexA() {
        return vertexA;
    }

    public void setVertexA(Vertex vertexA) {
        this.vertexA = vertexA;
    }

    public Vertex getVertexB() {
        return vertexB;
    }

    public void setVertexB(Vertex vertexB) {
        this.vertexB = vertexB;
    }

    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append(vertexA.label + "--" + vertexB.label + " = " + bobot);
        return buffer.toString();
    }

}
