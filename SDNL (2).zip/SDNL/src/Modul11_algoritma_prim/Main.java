/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul11_algoritma_prim;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Graph theGraph = new Graph(9);
        theGraph.addVertex("A"); // 0 
        theGraph.addVertex("B"); // 1
        theGraph.addVertex("C"); // 2
        theGraph.addVertex("D"); // 3
        theGraph.addVertex("E"); // 4
        theGraph.addVertex("F"); // 5
        theGraph.addVertex("G"); // 6
        theGraph.addVertex("H"); // 7
        theGraph.addVertex("I"); // 8
        System.out.println("Daftar Vertex : ");
        theGraph.toString();
        
        theGraph.addEdge("A", "B", 11);
        theGraph.addEdge("A", "F", 10);
        theGraph.addEdge("A", "I", 9);
        theGraph.addEdge("B", "C", 8);
        theGraph.addEdge("B", "E", 7);
        theGraph.addEdge("C", "D", 6);
        theGraph.addEdge("D", "H", 5);
        theGraph.addEdge("D", "G", 4);
        theGraph.addEdge("D", "F", 3);

        System.out.println("Matriks Adjency");
        theGraph.tampilMatrix();
        System.out.println("DFS :");
        theGraph.DFS();
        // memanggil DFS kemudian mencetak DFS dari kelas graph        
        System.out.println("");// mencetak ""
        System.out.println("\nBFS :");
        theGraph.BFS();

        System.out.println("\n");
        ArrayList<Edge> mt = theGraph.mst();
        for (int i = 0; i < mt.size(); i++) {
            System.out.println(mt.get(i).toString());
        }
        System.out.println("");
        int total = 0;
        for (int i = 0; i < mt.size(); i++) {
            total += mt.get(i).getBobot();

        }

        System.out.println("jarak terpendek adalah");
        System.out.println(total);
    }
}
