package MODUL3;

public class Main {

    public static void main(String[] args) {
        Tree sc = new Tree();
        sc.insert(42);
        sc.insert(21);
        sc.insert(38);
        sc.insert(27);
        sc.insert(71);
        sc.insert(82);
        sc.insert(55);
        sc.insert(63);
        sc.insert(6);
        sc.insert(2);
        sc.insert(12);

        System.out.println("Root: " + sc.root.getData());
        sc.depth(42);
        sc.height(6);
        sc.leaf();
        sc.descendant(1);
    }
}
