/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TreeNode1_CreateInsertSearch;

/**
 *
 * @author HP
 */
public class Tree {
  private TreeNode root;
    
Tree (){}
Tree (TreeNode root){
    this.root = root;
}

public TreeNode getRoot() {
        return root;
}
public void setRoot(TreeNode root) {
        this.root = root;
        this.root.setLeftNode(null);
        this.root.setRightNode(null);
}

public void insert (int data){
    TreeNode node = new TreeNode (data);
    TreeNode bantu = root, ting = null;
    if (root == null){
        root = node;
    } else {
        while (bantu != null){
            ting = bantu;
            if (node.getData() > bantu.getData()){
                if (bantu.getRightNode() == null){
                    bantu.setRightNode(node);
                    break;
                } else {
                    bantu = bantu.getRightNode();
                }
            } else if (node.getData() <= bantu.getData()){
                if (bantu.getLeftNode()== null){
                    bantu.setLeftNode(node);
                    break;
                } else {
                    bantu = bantu.getLeftNode();
                }
            }
    }
}
}
public TreeNode search (int data){
    TreeNode bantu = root;
    if (root == null){
        return null;
    } else {
        while (bantu != null){
            if (data == bantu.getData()){
                return bantu;
            } else {
                if (data > bantu.getData()){
                    bantu = bantu.getRightNode();
                } else {
                    bantu = bantu.getLeftNode();
                }
            }
        }
    }
        return null;
}

    public static void main(String[] args) {
        Tree kel = new Tree();
        kel.insert(42);
        kel.insert(21);
        kel.insert(38);
        kel.insert(27);
        kel.insert(71);
        kel.insert(82);
        kel.insert(55);
        kel.insert(63);
        kel.insert(6);
        kel.insert(2);
        kel.insert(40);
        kel.insert(12);
      
        System.out.println("Root: " + kel.root.getData());
        
        System.out.println("\n");
        int cari = 6;
        TreeNode bos = kel.search(cari);
        System.out.println("Data yang dicari: " + cari);
        if (bos != null){
            System.out.println("Ditemukan");
        } else{
            System.out.println("Tidak Ditemukan");
        }
        
        System.out.println("\n");
        int cari2 = 1;
        TreeNode bos2 = kel.search(cari2);
        System.out.println("Data yang dicari: " + cari2);
        if (bos2 != null){
            System.out.println("Ditemukan");
        } else{
            System.out.println("Tidak Ditemukan");
        }
    }
}