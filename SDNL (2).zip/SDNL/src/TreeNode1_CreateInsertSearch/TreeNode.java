/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TreeNode1_CreateInsertSearch;

/**
 *
 * @author HP
 */
public class TreeNode {
      private int data;
    private TreeNode leftNode;
    private TreeNode rightNode;
    
TreeNode (int data){
    this.data = data;
}
public int getData (){
    return data;
}
public void setData (int data){
    this.data = data;
}

public TreeNode getLeftNode() {
        return leftNode;
}
public void setLeftNode(TreeNode leftNode) {
        this.leftNode = leftNode;
}

public TreeNode getRightNode() {
        return rightNode;
}
public void setRightNode(TreeNode rightNode) {
        this.rightNode = rightNode;
}
}
//- Data : int - leftNode : TreeNode
//- rightNode : TreeNode
// TreeNode (int) : Constuctor
// getData() : int
// setData(int) : void
// getLeftNode() : TreeNode
// setLeftNode(TreeNode) : void
// getRightNode() : TreeNode
// setRightNode(TreeNode) : void