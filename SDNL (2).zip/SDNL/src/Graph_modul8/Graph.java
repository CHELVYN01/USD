
package Graph_modul8;

public class Graph {

    private int maxVartex = 5;
    private Vartex[] vertexList;
    private int[][] adjacencyMatrix;
    private int countVartex;

    public Graph() {
        vertexList = new Vartex[maxVartex];
        adjacencyMatrix = new int[maxVartex][maxVartex];

        for (int i = 0; i < maxVartex; i++) {
            for (int j = 0; j < maxVartex; j++) {
                if (i == j) {
                    adjacencyMatrix[i][j] = 0;
                }
            }
        }
    }

    public void addVartex(char label) {
        if (countVartex < maxVartex) {
            vertexList[countVartex] = new Vartex(label);
            countVartex++;
        }
    }

    public void addEdge(int satu, int dua, int value) {
        adjacencyMatrix[satu][dua] = value;
        adjacencyMatrix[dua][satu] = value;
    }

    public void addEdge(char satu, char dua, int value) {
        adjacencyMatrix[indexVartex(satu)][indexVartex(dua)] = value;
        adjacencyMatrix[indexVartex(dua)][indexVartex(satu)] = value;
    }

    private int indexVartex(char index) {
        for (int i = 0; i < vertexList.length; i++) {
            if (vertexList[i].getLabel() == index) {
                return i;
            }

        }
        return 0;
    }
    
    public String toString(){
        return "Graph{" + "maxVartex" + maxVartex + ", vartexList="
                + vertexList
                + ", adjacencyMatrix = "+ adjacencyMatrix + ", countVartex = "
                +countVartex  + '}';
    }
    public void show(){
        for (int i = 0; i < vertexList.length; i++) {
            for (int j = 0; j < vertexList.length; j++) {
                if (adjacencyMatrix[i][j] != 0) {
                    System.out.println(vertexList[i].getLabel()
                            + " terhubung dengan "
                            +vertexList[j].getLabel()+ " dengan bobot " 
                            + adjacencyMatrix[i][j]);
                }
            }
        }
    }
}
