/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph_modul8;


public class Vartex {
    char label;
    boolean flagvisited;
    
    public Vartex (char label ) {
        this.label = label;
        this.flagvisited = false;
        
                
    }
     char getLabel(){
        return label;
    }
    public void setLabel(char label){
        this.label = label;
    }
           
}
