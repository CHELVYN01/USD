/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph_modul8;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        Graph sc = new Graph();
        sc.addVartex('a');
        sc.addVartex('b');
        sc.addVartex('c');
        sc.addVartex('d');
        sc.addVartex('e');
        sc.addVartex('f');
        
        
        sc.addEdge('a','b',4 );
        sc.addEdge('a','f',5);
        sc.addEdge('b','c',5);
        sc.addEdge('b','e',4);
        sc.addEdge('b','f',2);
        sc.addEdge('c','e',2);
        sc.addEdge('c','f',4);
        sc.addEdge('e','f',10);
        
        sc.show();
        System.out.println("");
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
}
