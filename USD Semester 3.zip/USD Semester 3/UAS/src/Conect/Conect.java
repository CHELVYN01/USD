
package Conect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Conect {
    private static Connection koneksi;
    
    public static Connection getKoneksi(){
       if (koneksi == null){
           try {
        String host = "localhost";
        String port = "1521";
        String db = "xe";
        String usr = "hr";
        String pwd = "hr";
       
        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver() );
        koneksi = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":"+port+":"+db,usr,pwd);
               System.out.println("koneksi berhasil !!!!!");
           }
           catch (Exception ex){
               System.out.println("Erorr!!!!");
           }
       }
       return koneksi;
    }
    public static void main(String[] args) {
       getKoneksi();
    }
}