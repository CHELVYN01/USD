package Kasir_Toko_Kue;

import Conect.Conect;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elisabet_116, Yosefina_118
 */
public class Program extends javax.swing.JFrame {
    
        public ArrayList menu = new ArrayList ();
        public ArrayList harga = new ArrayList ();
        public ArrayList jumlah = new ArrayList ();
        public ArrayList subTotal = new ArrayList ();


    
    
    public Program() {
        initComponents();
    }
private void setHarga(){
    int harga = 0;
    int pilihan = boxKue.getSelectedIndex();
    switch (pilihan){
        case 1:
            harga = 20000;
            break;
        case 2:
            harga = 30000;
            break;
        case 3:
            harga = 40000;
            break;
        case 4:
            harga = 50000;
            break;
        case 5:
            harga = 60000;
            break;
        case 6:
            harga = 70000;
            break;
     }
    txtHarga.setText(""+ harga);
    
}
private void setHargaMinum(){
    int harga = 0; 
    int pilihan = boxMinum.getSelectedIndex();
    switch (pilihan){
        case 1:
            harga = 7000;
            break;
        case 2:
            harga = 5000;
            break;
        case 3:
            harga = 10000;
            break;
        case 4:
            harga = 15000;
            break;
        case 5:
            harga = 20000;
            break;
        case 6:
            harga = 25000;
            break;
     }
    txtHargaMinum.setText(""+ harga);
}
    private void setTabel(){
        int total = 0;
        double pajak = 0;
        
        DefaultTableModel tbl = new DefaultTableModel ();
        tbl.addColumn("Menu");
        tbl.addColumn("Harga");
        tbl.addColumn("Jumlah");
        tbl.addColumn("SubTotal");
        
        for(int i = 0; i < menu.size(); i++){
            total = total + Integer.parseInt(subTotal.get(i).toString());
            
            tbl.addRow(new Object []{
            menu.get(i),
            harga.get(i),
            jumlah.get(i),
            subTotal.get(i),
            
        });
        }
        dataTabel.setModel(tbl);
        
        }
    private boolean cekKosong(boolean kue){
        boolean hasil = true;
        
        if (kue == true){
            if (txtJumlah.getText().isEmpty()== true){
            JOptionPane.showMessageDialog(null, "Jumlah Cake Harus diisi!");
            hasil = true ;
           }
    }else {
     if (txtJumlahMinum.getText().isEmpty()== true){
            JOptionPane.showMessageDialog(null, "Jumlah Minuman Harus diisi!");
           
     }
        }
    return false;
}
    private boolean cekDataTabel(String Data){
        boolean hasil = menu.contains(Data);
        if (hasil == true ) JOptionPane.showMessageDialog(null, " Menu Sudah ditambahkan.");
        return hasil;
        
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        lKue = new javax.swing.JLabel();
        lHarga = new javax.swing.JLabel();
        lJumlah = new javax.swing.JLabel();
        lSubTotal = new javax.swing.JLabel();
        txtHarga = new javax.swing.JTextField();
        txtJumlah = new javax.swing.JTextField();
        txtSubTotal = new javax.swing.JTextField();
        btnJmKue = new javax.swing.JButton();
        txtHargaMinum = new javax.swing.JTextField();
        txtJumlahMinum = new javax.swing.JTextField();
        txtSubTotalMinum = new javax.swing.JTextField();
        btnJmMinum = new javax.swing.JButton();
        lMinum = new javax.swing.JLabel();
        lHargaMinum = new javax.swing.JLabel();
        lJumlahMinum = new javax.swing.JLabel();
        lSubTotalMinum = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        dataTabel = new javax.swing.JTable();
        boxKue = new javax.swing.JComboBox<>();
        boxMinum = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        btnMinum = new javax.swing.JButton();
        btnKue = new javax.swing.JButton();
        txtTotal = new javax.swing.JTextField();
        lTotal = new javax.swing.JLabel();
        txtJmBayar = new javax.swing.JTextField();
        lJmBayar = new javax.swing.JLabel();
        simpan = new javax.swing.JButton();
        btnBayar = new javax.swing.JButton();
        txtKembalian = new javax.swing.JTextField();
        lKembalian = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        jTextField1.setText("jTextField");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Gabriola", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TOKO KUE NONA ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 590, -1));

        lKue.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lKue.setText("MENU KUE : ");
        getContentPane().add(lKue, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 65, -1, 19));

        lHarga.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lHarga.setText("HARGA : ");
        getContentPane().add(lHarga, new org.netbeans.lib.awtextra.AbsoluteConstraints(36, 93, -1, -1));

        lJumlah.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lJumlah.setText("JUMLAH : ");
        getContentPane().add(lJumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 131, -1, -1));

        lSubTotal.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lSubTotal.setText("SUB TOTAL : ");
        getContentPane().add(lSubTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 169, -1, -1));

        txtHarga.setEditable(false);
        txtHarga.setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().add(txtHarga, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 90, 145, -1));

        txtJumlah.setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().add(txtJumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 128, 100, -1));

        txtSubTotal.setEditable(false);
        txtSubTotal.setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().add(txtSubTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 166, 145, -1));

        btnJmKue.setBackground(new java.awt.Color(255, 153, 153));
        btnJmKue.setText("\"");
        btnJmKue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJmKueActionPerformed(evt);
            }
        });
        getContentPane().add(btnJmKue, new org.netbeans.lib.awtextra.AbsoluteConstraints(191, 128, 39, 20));

        txtHargaMinum.setEditable(false);
        txtHargaMinum.setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().add(txtHargaMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(466, 90, 145, -1));

        txtJumlahMinum.setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().add(txtJumlahMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(466, 128, 100, -1));

        txtSubTotalMinum.setEditable(false);
        txtSubTotalMinum.setBackground(new java.awt.Color(255, 153, 153));
        getContentPane().add(txtSubTotalMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(466, 166, 145, -1));

        btnJmMinum.setBackground(new java.awt.Color(255, 153, 153));
        btnJmMinum.setText("\"");
        btnJmMinum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJmMinumActionPerformed(evt);
            }
        });
        getContentPane().add(btnJmMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(572, 128, 39, 20));

        lMinum.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lMinum.setText("MENU MINUMAN : ");
        getContentPane().add(lMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 65, -1, 19));

        lHargaMinum.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lHargaMinum.setText("HARGA : ");
        getContentPane().add(lHargaMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(417, 93, -1, -1));

        lJumlahMinum.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lJumlahMinum.setText("JUMLAH : ");
        getContentPane().add(lJumlahMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(413, 131, -1, -1));

        lSubTotalMinum.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lSubTotalMinum.setText("SUB TOTAL : ");
        getContentPane().add(lSubTotalMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(398, 169, -1, -1));

        dataTabel.setBackground(new java.awt.Color(255, 153, 153));
        dataTabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nama", "Harga", "Jumlah ", "Sub Total"
            }
        ));
        jScrollPane4.setViewportView(dataTabel);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 245, 600, 90));

        boxKue.setBackground(new java.awt.Color(255, 153, 153));
        boxKue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-PILIH-", "Chocolate Cake", "Brownis", "Blackforest", "Nastar", "Roti Tawar", "Nagasari", " " }));
        boxKue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxKueActionPerformed(evt);
            }
        });
        getContentPane().add(boxKue, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 64, 145, -1));

        boxMinum.setBackground(new java.awt.Color(255, 153, 153));
        boxMinum.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-PILIH-", "Coffe", "Hot Tea", "Ice Drink", "Fruit Tea", "Hot Chocolate", "Fresh Milk", " " }));
        boxMinum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxMinumActionPerformed(evt);
            }
        });
        getContentPane().add(boxMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(466, 64, 145, -1));

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnMinum.setBackground(new java.awt.Color(255, 153, 153));
        btnMinum.setFont(new java.awt.Font("Nirmala UI", 1, 12)); // NOI18N
        btnMinum.setText("TAMBAHAN");
        btnMinum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMinumActionPerformed(evt);
            }
        });
        jPanel1.add(btnMinum, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, -1, -1));

        btnKue.setBackground(new java.awt.Color(255, 153, 153));
        btnKue.setFont(new java.awt.Font("Nirmala UI", 1, 12)); // NOI18N
        btnKue.setText("TAMBAHAN");
        btnKue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKueActionPerformed(evt);
            }
        });
        jPanel1.add(btnKue, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 200, -1, -1));

        txtTotal.setEditable(false);
        txtTotal.setBackground(new java.awt.Color(255, 153, 153));
        jPanel1.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 360, 158, -1));

        lTotal.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lTotal.setText("TOTAL :");
        jPanel1.add(lTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 370, -1, -1));

        txtJmBayar.setBackground(new java.awt.Color(255, 153, 153));
        jPanel1.add(txtJmBayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 360, 164, -1));

        lJmBayar.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lJmBayar.setText("JUMLAH BAYAR :");
        jPanel1.add(lJmBayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 370, -1, 10));

        simpan.setBackground(new java.awt.Color(255, 153, 153));
        simpan.setFont(new java.awt.Font("Nirmala UI", 1, 12)); // NOI18N
        simpan.setText("simpan");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        jPanel1.add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 480, -1, -1));

        btnBayar.setBackground(new java.awt.Color(255, 153, 153));
        btnBayar.setFont(new java.awt.Font("Nirmala UI", 1, 12)); // NOI18N
        btnBayar.setText("BAYAR");
        jPanel1.add(btnBayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 440, -1, -1));

        txtKembalian.setEditable(false);
        txtKembalian.setBackground(new java.awt.Color(255, 153, 153));
        jPanel1.add(txtKembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 480, 164, -1));

        lKembalian.setFont(new java.awt.Font("Gabriola", 1, 12)); // NOI18N
        lKembalian.setText("KEMBALIAN :");
        jPanel1.add(lKembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, -1, -1));

        jButton1.setBackground(new java.awt.Color(255, 153, 153));
        jButton1.setFont(new java.awt.Font("Nirmala UI", 1, 12)); // NOI18N
        jButton1.setText("Cetak");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 480, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 620, 520));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnJmKueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJmKueActionPerformed
        // TODO add your handling code here:
        try{
            int harga = Integer.parseInt(txtHarga.getText());
            int jumlah = Integer.parseInt(txtJumlah.getText());
            txtSubTotal.setText("" + (harga*jumlah));
        }
        catch (NumberFormatException e ){
            txtSubTotal.setText("0");
        }
        
    }//GEN-LAST:event_btnJmKueActionPerformed

    private void btnJmMinumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJmMinumActionPerformed
        // TODO add your handling code here:
        try{
            int hargaMinum = Integer.parseInt(txtHargaMinum.getText());
            int jumlahMinum = Integer.parseInt(txtJumlahMinum.getText());
            txtSubTotalMinum.setText("" + (hargaMinum * jumlahMinum));
        }
        catch (NumberFormatException e ){
            txtSubTotal.setText("0");
        }
    }//GEN-LAST:event_btnJmMinumActionPerformed

    private void boxKueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxKueActionPerformed
        // TODO add your handling code here:
        setHarga();
    }//GEN-LAST:event_boxKueActionPerformed

    private void boxMinumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxMinumActionPerformed
        // TODO add your handling code here:
        setHargaMinum();
    }//GEN-LAST:event_boxMinumActionPerformed

    private void btnKueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKueActionPerformed
        // TODO add your handling code here:
        if (cekKosong (true) == false){
            String menuItem = boxKue.getSelectedItem().toString();
            if(cekDataTabel(menuItem) == false ){
            
            int hrg = Integer.parseInt(txtHarga.getText());
             int kuant = Integer.parseInt(txtJumlah.getText());
              txtSubTotal.setText("" + (hrg * kuant));
              
              menu.add(menuItem);
              harga.add(txtHarga.getText());
              jumlah.add(txtJumlah.getText());
              subTotal.add(txtSubTotal.getText());
              
              setTabel();
//       boxKue.setSelectedIndex(0);
//       txtHarga.setText("");
//       txtJumlah.setText("");
//       txtSubTotal.setText("");
       
            }
        }
       String nama = boxKue.getSelectedItem().toString().trim();
       String harga = txtHarga.getText().toString().trim();
       String jumlah = txtJumlah.getText().toString().trim();
       String sub = txtSubTotal.getText().toString().trim();
        
       try {
             Connection c =  Conect.getKoneksi();
             String sql = "insert into toko values (?, ?, ?, ?)";
             PreparedStatement sim =c.prepareStatement(sql);
             
             sim.setString(1, nama);
             sim.setString(2, harga);
             sim.setString(3, jumlah);
             sim.setString(4, sub);
             sim.executeUpdate();
             sim.close();
             

             
       }
        catch (SQLException ex){
             JOptionPane.showMessageDialog(null, "mohon maaf terjadi kesalahan di databasenya");
            
        }
               
        
    }//GEN-LAST:event_btnKueActionPerformed
  
      
             
    
    
       
    private void btnMinumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMinumActionPerformed
        // TODO add your handling code here:
         if (cekKosong (false) == false){
            String menuItem = boxMinum.getSelectedItem().toString();
            if(cekDataTabel(menuItem) == false ){
            
            int hrg = Integer.parseInt(txtHargaMinum.getText());
             int kuant = Integer.parseInt(txtJumlahMinum.getText());
              txtSubTotalMinum.setText("" + (hrg * kuant));
              
              menu.add(menuItem);
              harga.add(txtHargaMinum.getText());
              jumlah.add(txtJumlahMinum.getText());
              subTotal.add(txtSubTotalMinum.getText());
              
              setTabel();        
        }
    }                                      
//  boxMinum.setSelectedIndex(0);
//       txtHargaMinum.setText("");
//       txtJumlahMinum.setText("");
//       txtSubTotalMinum.setText("");
//       
       String nama = boxMinum.getSelectedItem().toString().trim();
       String harga = txtHargaMinum.getText().toString().trim();
       String jumlah = txtJumlahMinum.getText().toString().trim();
       String sub = txtSubTotalMinum.getText().toString().trim();
        
       try {
             Connection c =  Conect.getKoneksi();
             String sql = "insert into toko values (?, ?, ?, ?)";
             PreparedStatement sim =c.prepareStatement(sql);
             
             sim.setString(1, nama);
             sim.setString(2, harga);
             sim.setString(3, jumlah);
             sim.setString(4, sub);
             sim.executeUpdate();
             sim.close();
             

             
       }
        catch (SQLException ex){
             JOptionPane.showMessageDialog(null, "mohon maaf terjadi kesalahan di databasenya");
            
        }
               
    }//GEN-LAST:event_btnMinumActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
          JFileChooser chooser = new JFileChooser();
    int status = chooser.showSaveDialog(null);
    if(status == JFileChooser.APPROVE_OPTION ){
      
        File simpan = chooser.getSelectedFile();
        
        try {
            FileWriter tp = new FileWriter(simpan.getPath());
            BufferedWriter bw = new BufferedWriter(tp);
             for (int i = 0; i < dataTabel.getRowCount(); i++){
           for(int j = 0; j< dataTabel.getColumnCount(); j++){
             bw.write(dataTabel.getValueAt(i, j)+" ");
                }
               bw.newLine();
            }
            
            bw.flush();
            bw.close();
            
        }
        catch (Exception ec){
            System.out.println("Error :" + ec.getMessage());
        }
        
    }

    }//GEN-LAST:event_simpanActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     Cetak c = new Cetak();
     this.dispose();
     c.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed
     
    
       
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Program.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Program.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Program.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Program.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Program().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> boxKue;
    private javax.swing.JComboBox<String> boxMinum;
    private javax.swing.JButton btnBayar;
    private javax.swing.JButton btnJmKue;
    private javax.swing.JButton btnJmMinum;
    private javax.swing.JButton btnKue;
    private javax.swing.JButton btnMinum;
    private javax.swing.JTable dataTabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lHarga;
    private javax.swing.JLabel lHargaMinum;
    private javax.swing.JLabel lJmBayar;
    private javax.swing.JLabel lJumlah;
    private javax.swing.JLabel lJumlahMinum;
    private javax.swing.JLabel lKembalian;
    private javax.swing.JLabel lKue;
    private javax.swing.JLabel lMinum;
    private javax.swing.JLabel lSubTotal;
    private javax.swing.JLabel lSubTotalMinum;
    private javax.swing.JLabel lTotal;
    private javax.swing.JButton simpan;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtHargaMinum;
    private javax.swing.JTextField txtJmBayar;
    private javax.swing.JTextField txtJumlah;
    private javax.swing.JTextField txtJumlahMinum;
    private javax.swing.JTextField txtKembalian;
    private javax.swing.JTextField txtSubTotal;
    private javax.swing.JTextField txtSubTotalMinum;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
