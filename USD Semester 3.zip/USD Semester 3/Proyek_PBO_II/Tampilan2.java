package Proyek_PBO_II;

import Proyek_PBO_II.Connect.connect;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Tampilan2 extends javax.swing.JFrame {

    /**
     * Creates new form Tampilan2
     */
    public Tampilan2() {
        initComponents();
        this.setTitle("Tampilan 2");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgJenisKelamin = new javax.swing.ButtonGroup();
        name = new javax.swing.JLabel();
        nim = new javax.swing.JLabel();
        prodi = new javax.swing.JLabel();
        sex = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        contact = new javax.swing.JLabel();
        alamat = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtNim = new javax.swing.JTextField();
        txtProdi = new javax.swing.JTextField();
        rbL = new javax.swing.JRadioButton();
        rbP = new javax.swing.JRadioButton();
        txtEmail = new javax.swing.JTextField();
        txtContact = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaAlamat = new javax.swing.JTextArea();
        send = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        name.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        name.setText("NAMA :");

        nim.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        nim.setText("NIM :");

        prodi.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        prodi.setText("PRODI :");

        sex.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        sex.setText("JENIS KELAMIN :");

        email.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        email.setText("EMAIL :");

        contact.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        contact.setText("CONTACT :");

        alamat.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        alamat.setText("ALAMAT :");

        txtName.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        txtNim.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        txtProdi.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        bgJenisKelamin.add(rbL);
        rbL.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        rbL.setText("L");

        bgJenisKelamin.add(rbP);
        rbP.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        rbP.setText("P");

        txtEmail.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        txtContact.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        txtAreaAlamat.setColumns(20);
        txtAreaAlamat.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtAreaAlamat.setRows(5);
        jScrollPane1.setViewportView(txtAreaAlamat);

        send.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        send.setText("SEND");
        send.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sendMouseClicked(evt);
            }
        });
        send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("FORMULIR PENDAFTARAN");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(82, 82, 82))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nim, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(prodi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sex, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(email, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(contact, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(alamat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(send)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(rbP)
                        .addComponent(txtName)
                        .addComponent(txtNim)
                        .addComponent(txtProdi)
                        .addComponent(rbL)
                        .addComponent(txtEmail)
                        .addComponent(txtContact)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)))
                .addContainerGap(66, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nim)
                    .addComponent(txtNim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prodi)
                    .addComponent(txtProdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sex)
                    .addComponent(rbL))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rbP)
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(contact)
                    .addComponent(txtContact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(alamat)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(send)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void sendMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sendMouseClicked

    }//GEN-LAST:event_sendMouseClicked

    private void sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendActionPerformed
        String nama = txtName.getText().toString().trim();
        String nim = txtNim.getText().toString().trim();
        String prodi = txtProdi.getText().toString().trim();
        String jK = null;
        if (rbL.isSelected()) {
            jK = "Laki-laki";
        } else {
            jK = "Perempuan";
        }
        String email = txtEmail.getText().toString().trim();
        String contact = txtContact.getText().toString().trim();
        String alamat = txtAreaAlamat.getText().toString().trim();

        if (nama.equals("")) {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong");
            txtName.requestFocus();
        } else if (nim.equals("")) {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong");
            txtNim.requestFocus();
        } else if (prodi.equals("")) {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong");
            txtProdi.requestFocus();
        } else if (email.equals("")) {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong");
            txtEmail.requestFocus();
        } else if (contact.equals("")) {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong");
            txtContact.requestFocus();
        } else if (alamat.equals("")) {
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong");
            txtAreaAlamat.requestFocus();
        } else {
            try {
                Connection tea = connect.getKoneksi();
                String sql = "insert into seminar values (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement p = tea.prepareStatement(sql);
                p.setString(1, nama);
                p.setString(2, nim);
                p.setString(3, prodi);
                p.setString(4, jK);
                p.setString(5, email);
                p.setString(6, contact);
                p.setString(7, alamat);
                p.executeUpdate();
                p.close();
                JOptionPane.showMessageDialog(null, "Data telah tersimpan");
            } catch (SQLException exe) {
                JOptionPane.showMessageDialog(null, "Gagal");
                exe.printStackTrace();
            } finally {
                Tampilan3 tea = new Tampilan3();
                tea.setVisible(true);
                this.dispose();
            }
        }
    }//GEN-LAST:event_sendActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tampilan2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel alamat;
    private javax.swing.ButtonGroup bgJenisKelamin;
    private javax.swing.JLabel contact;
    private javax.swing.JLabel email;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel name;
    private javax.swing.JLabel nim;
    private javax.swing.JLabel prodi;
    private javax.swing.JRadioButton rbL;
    private javax.swing.JRadioButton rbP;
    private javax.swing.JButton send;
    private javax.swing.JLabel sex;
    private javax.swing.JTextArea txtAreaAlamat;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtNim;
    private javax.swing.JTextField txtProdi;
    // End of variables declaration//GEN-END:variables
}
