

package pkg205314117_kelvin_kleden;

public class Administrasi extends Karyawan  {
   private String sertifikatKomputer;

    public Administrasi() {
    }

    public void setSertifikatKomputer(String sertifikatKomputer) {
        this.sertifikatKomputer = sertifikatKomputer;
    }
   
   public void setNIK (String NIK){
       
}
}