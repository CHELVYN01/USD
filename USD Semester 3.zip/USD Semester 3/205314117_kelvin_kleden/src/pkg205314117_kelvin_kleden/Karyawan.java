

package pkg205314117_kelvin_kleden;

public class Karyawan {
   protected String NIK;

    public Karyawan() {
    }

    public Karyawan(String NIK) {
        this.NIK = NIK;
    }
   
   
}
