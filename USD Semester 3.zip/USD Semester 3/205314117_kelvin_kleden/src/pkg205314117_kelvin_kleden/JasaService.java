

package pkg205314117_kelvin_kleden;

public class JasaService {
 private Mekanik mekanik;
 private String jenisService;
 private double harga;

    public JasaService(Mekanik mekanik, String jenisService, double harga) {
        this.mekanik = mekanik;
        this.jenisService = jenisService;
        this.harga = harga;
    }

    public String getJenisService() {
        return jenisService;
    }
 
 public double getTagihan(){
     return harga;
 }
}
