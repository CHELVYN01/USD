

package pkg205314117_kelvin_kleden;


public class Pelanggan {
 private int nomor;
 private String nama;
 
 public Pelanggan(int nomor,String nama){
  this.nomor = nomor;
  this.nama = nama;
 }
 public Pelanggan(){
     
 }

    public int getNomor() {
        return nomor;
    }

    public void setNomer(int nomor) {
        this.nomor = nomor;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    @Override
    public String toString() {
        return "Pelanggan{" + "nomor=" + nomor + ", nama=" + nama + '}';
    }

}
 