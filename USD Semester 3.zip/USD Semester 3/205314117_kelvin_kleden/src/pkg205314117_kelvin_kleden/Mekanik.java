
package pkg205314117_kelvin_kleden;

public class Mekanik extends Karyawan {
 private String sertfikatMekanik;

    public Mekanik(String sertfikatMekanik , String NIK) {
        this.sertfikatMekanik = sertfikatMekanik;
        this.NIK = NIK;
    }
 
 
}
