/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pkg205314117_kelvin_kleden;


public class DetailService {
    private String idservice;
    private Pelanggan pelanggan;
    private Tagihan[] tagihan;
    private int maxTagihan;
    private int tagihanKe;
    private double totalpart;
    private double totalservice;

    public DetailService(String idservice, Pelanggan pelanggan) {
        this.idservice = idservice;
        this.pelanggan = pelanggan;
    }

    public DetailService(int maxTagihan) {
        this.maxTagihan = 100;
        
    }

   
    public void addtagihan(Tagihan addtagihan){
        if (addtagihan = SparePart){
            sparepat
            
        }
   
    }

    public String getIdservice() {
        return idservice;
    }

    public Pelanggan getPelanggan() {
        return pelanggan;
    }

    public void setIdservice(String idservice) {
        this.idservice = idservice;
    }

    public void setPelanggan(Pelanggan pelanggan) {
        this.pelanggan = pelanggan;
    }
    public void printDetailService(){
    }
    
    
   
    
    
}
