

package pkg205314117_kelvin_kleden;

public class SparePart {
  private String kodepart;
  private double harga;
  private double jumlah;

    public SparePart(String kodepart, double harga, double jumlah) {
        this.kodepart = kodepart;
        this.harga = harga;
        this.jumlah = jumlah;
    }
  
  public double getTagihan(){
      return  harga * jumlah;
  }
      
  
      
  

    @Override
    public String toString() {
        return "SparePart{" + "kodepart=" + kodepart + ", harga=" + harga + ", jumlah=" + jumlah + '}';
    }
  
}
