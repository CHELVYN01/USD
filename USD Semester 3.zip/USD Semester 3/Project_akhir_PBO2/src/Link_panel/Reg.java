/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Link_panel;

/**
 *
 * @author HP
 */
public class Reg {
     private String NL;
    private String Ttl;
    private String KTP;
    private String noHP;
    private String JenisKelamin;
    private String MetodPembayaran;
    
    public Reg(){
        
    }

    public String getNL() {
        return NL;
    }

    public void setNL(String NL) {
        this.NL = NL;
    }

    public String getTtl() {
        return Ttl;
    }

    public void setTtl(String Ttl) {
        this.Ttl = Ttl;
    }

    public String getKTP() {
        return KTP;
    }

    public void setKTP(String KTP) {
        this.KTP = KTP;
    }

    public String getNoHP() {
        return noHP;
    }

    public void setNoHP(String noHP) {
        this.noHP = noHP;
    }

    public String getJenisKelamin() {
        return JenisKelamin;
    }

    public void setJenisKelamin(String JenisKelamin) {
        this.JenisKelamin = JenisKelamin;
    }

    public String getMetodPembayaran() {
        return MetodPembayaran;
    }

    public void setMetodPembayaran(String MetodPembayaran) {
        this.MetodPembayaran = MetodPembayaran;
    }
    
}
