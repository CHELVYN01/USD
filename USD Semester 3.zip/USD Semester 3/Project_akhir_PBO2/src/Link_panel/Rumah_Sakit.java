
package Link_panel;

/**
 *
 * @author HP
 */
public class Rumah_Sakit {
    
   private String namaPasian;
   private String tanggalLahir;
   private String alamat;
   private String jenisKelamin;
   private String Status;
   private String agama;
   private String ktp;
   private String no_hp;
   private String metode;
   
   public Rumah_Sakit(){
       
   }

    public String getNamaPasian() {
        return namaPasian;
    }

    public void setNamaPasian(String namaPasian) {
        this.namaPasian = namaPasian;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getAgama() {
        return agama;
    }

    public void setAgama(String agama) {
        this.agama = agama;
    }

    public String getKtp() {
        return ktp;
    }

    public void setKtp(String ktp) {
        this.ktp = ktp;
    }

    public String getNo_hp() {
        return no_hp;
    }

    public void setNo_hp(String no_hp) {
        this.no_hp = no_hp;
    }

    public String getMetode() {
        return metode;
    }

    public void setMetode(String metode) {
        this.metode = metode;
    }
   
   
}
