
package sql_connect;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class SQL_Connect {

    public static void main(String[] args) {
    SQL_Connect kel = new SQL_Connect();
    Connection conn = kel.getConnection();
    Scanner sc = new Scanner (System.in);
    
    try{
        conn.close();
        
    }catch (SQLException ex){
        System.out.println(ex.getMessage());
    }
   
        System.out.println("Menu :");
        System.out.println("1. Lihat isi table :");
        System.out.println("2. Tambah Data :");
        System.out.println("3. Hapus Data :");
        System.out.println("4. update Data :");
        System.out.println("5. keluar :");
        int input = 0;
        while (input != 5){
            System.out.print("pilih menu ? :");
            input = sc.nextInt();
            switch (input){
                case 1:
                    kel.showData();
                    break;
                case 2:
                    kel.inputData();
                    break;
                case 3:
                    kel.hapusData();
                    break;
                case 4:
                    kel.updateData();
                    break;
                default :
                    break;
            }
        }
    }
    public Connection getConnection(){
         String jdbcURL = "jdbc:mysql://localhost:3306/mahasiswa";
        String port = "3306";
        String user = "root"; 
        String pwd = "";
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(ClassNotFoundException ex){
            System.out.println("Maaf, driver class tidak ditemukan");
            System.out.println(ex.getMessage());
        }
        Connection conn = null;
        try{
            conn = (Connection) DriverManager.getConnection(jdbcURL, user, pwd);
        }
    catch(SQLException ex){
        System.out.println("Maaf, koneksi tidak berhasil");
        System.out.println(ex.getMessage());
    }
       
    if(conn != null){
        System.out.println("koneksi dateBase berhasil terbentuk");
    }
    else {
        System.out.println("maaf koneksi tidah terhubung ke dataBase");
    }
    return conn;
    }
     public void showData(){
        java.sql.Connection conn = null;
        Statement st = null;
        ResultSet rd = null;
        
        conn = this.getConnection();
        
        try{
            st = conn.createStatement();
            rd = st.executeQuery("select * from data_mahasiswa");
            
            System.out.println("NIM\t\tNama\tIPK");
            while(rd.next()){
                System.out.println(rd.getString(1)+"1"+"\t"+rd.getString(2)+"\t"+rd.getString(3));
            }
        }
        catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
        finally{
            try{
                rd.close();
                st.close();
                conn.close();
                
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
    }
    //latihan 3
    public void inputData(){
        java.sql.Connection conn = null;
        PreparedStatement ps = null;
        
        conn = this.getConnection();
        
        Scanner sy = new Scanner(System.in);
        System.out.println("INPUT DATA");
        System.out.print("MASUKAN NIM :");
        String nim = sy.nextLine();
        System.out.print("MASUKAN NAMA :");
        String nama = sy.nextLine();
        System.out.print("MASUKAN IPK :");
        double ipk = sy.nextDouble();
        
        try{
            ps = conn.prepareStatement("insert into LOGIN values (?,?,?)");
            ps.setString(1, nim);
            ps.setString(2, nama);
            ps.setDouble(3, ipk);
            ps.executeUpdate();
            conn.commit();
            System.out.println("data suadah ditambahkan ");
            
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        finally{
            try {
                ps.close();
                conn.close();
            }
            catch (SQLException ex){
            System.out.println(ex.getMessage());
            }
        }
    }
    // latihan 4
    public void hapusData(){
          java.sql.Connection conn = null;
        PreparedStatement pc = null;
        
        conn = this.getConnection();
        Scanner sn = new Scanner(System.in);
        System.out.println("DELATE DATA");
        System.out.println("Masukan nim yang akan dihapus");
        String nim = sn.nextLine();
        
        try {
            pc = conn.prepareStatement("delete from data_mahasiswa where nim =?");
            pc.setString(1, nim);
            pc.executeUpdate();
            conn.commit();
            System.out.println("Data sudah di hapus");
            
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                pc.close();
                conn.close();
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
    }
    public void updateData(){
        java.sql.Connection conn = null;
        PreparedStatement px = null;
        
        conn = this.getConnection();
        
        Scanner kel = new Scanner(System.in);
        
        System.out.println("UPDATE DATA");
        System.out.print("Masukan NIM yang akan di Update :");
        String nim = kel.next();
        System.out.print("Masukan koreksi nama :");
        String nama = kel.next();
        System.out.print("Masukan ipk :");
        double ipk = kel.nextDouble();
        
        try {
            px = conn.prepareStatement("update mahasiswa set nama =?,ipk =?, where nim =?");
            px.setString(1, nim);
            px.setDouble(2, ipk);
            px.setString(3, nama);
           
            px.executeUpdate();
            conn.commit();
            System.out.println("data suadah ditambahkan ");
        }
       
            catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                px.close();
                conn.close();
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        
        }
    }
    
}
