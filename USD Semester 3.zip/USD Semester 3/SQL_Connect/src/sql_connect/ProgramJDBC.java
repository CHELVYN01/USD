/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sql_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ProgramJDBC {
   
    public static void main(String[] args) {
        System.out.println("PROGRAM LATIHAN JDBC");
        System.out.println("====================");
        
        System.out.println("mencoba membuat koneksi ke database");
        ProgramJDBC p = new ProgramJDBC();
        Connection conn = p.getConnection();
        
        try {
            conn.close();
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
    }
    public Connection getConnection(){
        String host = "localhost";
        String port = "1521";
        String db = "xe";
        String usr = "hr";
        String pwd = "hr";
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
        
        }  catch(ClassNotFoundException ex){
            System.out.println("Maaf, driver class tidak ditemukan");
            System.out.println(ex.getMessage());
                  
    }
       //hubungkan ke sumber data 
       Connection conn = null;
       try{
           conn = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":"+port+":"+db,usr,pwd);
       }
       catch (SQLException ex){
           
           System.out.println("maaf koneksi tidak berhasil");
            System.out.println(ex.getMessage());
       }
       
       if(conn != null){
           System.out.println("koneksi ke database berhasil terbentuk");
       }else{
           System.out.println("maaf, koneksi ke dalam database gagal terbentuk");
       }
       return conn;
       }
       
}
