// tugas3
package pkg205314117_uts_pbo;

import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class login extends JFrame {
    private static final int FRAME_WIDHT        =750;
    private static final int FRAME_HEIGHT       =200;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_WIDTH       =80;
    private static final int BUTTON_HIGHT       =30;   
    private JButton tombol_login;
    private JLabel user,pasword;
    private JTextField nama , pin;
    
    

    public static void main(String[] args) {
        login l = new login();
        l.setVisible(true);
    }
    
    public login (){
        Container contentpane = getContentPane();
        contentpane.setLayout(null);
        
         //set size
        this.setSize(FRAME_WIDHT, FRAME_HEIGHT);
        this.setResizable(false);
        this.setTitle("Login Form");
        this.setLocation(FRAME_X_ORIGIN , FRAME_Y_ORIGIN);
       
        // lebel 
        user = new JLabel("user name :");
        pasword = new JLabel ("password :");
       
        //textField\
        nama = new JTextField();
        pin = new JTextField ();
        
        //button
        tombol_login = new JButton("login");
        
        //size 
        user.setBounds(10, 60,120  ,BUTTON_HIGHT);
        pasword.setBounds(250, 60,120  ,BUTTON_HIGHT);
        nama.setBounds(100, 60,120  ,BUTTON_HIGHT);
        pin.setBounds(350, 60,120  ,BUTTON_HIGHT);
        tombol_login.setBounds(550, 60,120  ,BUTTON_HIGHT);
        
        
        // masukan ke frame 
         contentpane.add(user);
         contentpane.add(pasword);
         contentpane.add(nama);
         contentpane.add(pin);
         contentpane.add(tombol_login);
         
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
}
