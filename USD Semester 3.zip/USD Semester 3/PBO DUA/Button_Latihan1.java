package pbo2_eventhandling;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * @Ingrida
 */
public class Button_Latihan1 extends javax.swing.JFrame
  implements java.awt.event.ActionListener
           
{
    private final  JLabel numberOfClicksLabel;
    private int numberOfClicks=0;
    private JButton swingButton;
    
 
    public Button_Latihan1() {
        //instance label and button
        super("SwingApplication");
        numberOfClicksLabel = new JLabel("Number of button clicks: "+getNumberOfClicks());
        swingButton = new JButton("I'm swing button");
        
        this.setLayout(new FlowLayout());
        this.add(swingButton);
        this.add(numberOfClicksLabel);
        
        swingButton.addActionListener((ActionListener) this);
    }
public int getNumberOfClicks() {
        return numberOfClicks;
    }

    public void setNumberOfClicks(int numberOfClicks) {
        this.numberOfClicks = numberOfClicks;
    }
    
    public void actionPerformed(ActionEvent e) {  
        setNumberOfClicks(getNumberOfClicks()+1);
        numberOfClicksLabel.setText("Number of button clicks: "+getNumberOfClicks());        
   }
    
    public static void main (String args[]){
        Button_Latihan1 simpleGUI = new Button_Latihan1();
        simpleGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        simpleGUI.setSize(300,200);
        simpleGUI.setVisible(true);
    }
}

  