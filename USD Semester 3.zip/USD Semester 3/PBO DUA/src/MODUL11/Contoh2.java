/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODUL11;

/**
 *
 * @author HP
 */
public class Contoh2 extends Thread {
     public void run(){
      try{
          for (int x = 1; x <= 5; x++){
              System.out.println("angka"+x);
              Thread.sleep(1000);
          }
        
      }
        catch (Exception e){
                  e.printStackTrace();
                  }
  }
     public static void main(String[] args) {
        Contoh2 out = new Contoh2();
        Contoh2 out2 = new Contoh2();
        
        out.start();
        out2.start();
        
    }
     
}
