/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODUL11;

/**
 *
 * @author HP
 */
public class Contoh3 implements Runnable {

    @Override
    public void run() {
          for (int x = 1; x <= 5; x++){
         try{
        
              System.out.println("angka"+x);
              Thread.sleep(1000);
          }
        catch (Exception e){
              System.out.println("pesan eror :"+ e.getMessage());
                  }
          }
    }
    public static void main(String[] args) {
        Contoh3 out = new Contoh3();
        
        Thread td = new Thread(out);
        td.start();
    }
}
