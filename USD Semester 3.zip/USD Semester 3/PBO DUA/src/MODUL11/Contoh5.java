/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODUL11;

import java.awt.Container;
import java.awt.Font;
import java.util.Calendar;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Contoh5 extends JFrame implements Runnable{
    private static final int FRAME_WIDTH = 490;
    private static final int FRAME_HEIGHT = 190;
    private static final int FRAME_X_ORIGIN = 300;
    private static final int FRAME_Y_ORIGIN = 300;
    private JLabel jam;

    public Contoh5() {
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.setResizable(false);
        this.setTitle("Digital Clock");
        this.setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);
        
        jam = new JLabel();
        jam.setFont(new Font("Times New Roman", Font.BOLD, 70));
        jam.setBounds(35, 12, 310, 130);
        contentPane.add(jam);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void run() {
        while (true) {
            Calendar cal = Calendar.getInstance();
            int s = cal.get(Calendar.SECOND);
            int m = cal.get(Calendar.MINUTE);
            int h = cal.get(Calendar.HOUR_OF_DAY);
            
            String format = h + ":" + m + ":" + s;
            jam.setText(format);
            
        }

    }


    public static void main(String[] args) {
        Contoh5 out = new Contoh5();
        Thread td = new Thread(out);
        td.start();
        out.setVisible(true);
    }
}