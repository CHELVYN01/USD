/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MODUL6.Latihan3;

import java.text.DecimalFormat;


public class coba {
    private String nim;
    private String nama;
    private String mk;
    private String jmlpertemuan;
    private String jlmkehadiran;

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getMk() {
        return mk;
    }

    public void setMk(String mk) {
        this.mk = mk;
    }

    public String getJmlpertemuan() {
        return jmlpertemuan;
    }

    public void setJmlpertemuan(String jmlpertemuan) {
        this.jmlpertemuan = jmlpertemuan;
    }

    public String getJlmkehadiran() {
        return jlmkehadiran;
    }

    public void setJlmkehadiran(String jlmkehadiran) {
        this.jlmkehadiran = jlmkehadiran;
    }
    
    public void hasil(){
         DecimalFormat k = new DecimalFormat("#.##");
        double hasil ;
        String ank1 = getJmlpertemuan();
        String ank2 = getJlmkehadiran();
        double kel = Double.parseDouble(ank1);
        double kel2 = Double.parseDouble(ank2);
        hasil = (kel2 / kel)*100;
        
         if (hasil> 75){
            System.out.println("Status\t\t\t\t :"+"Memenuhi");
        }
        else{
            System.out.println("Status\t\t\t\t :"+"Tidak Memenuhi");
        }
    }
    
    
}
