 // menampilkan frame dengan posisi yang tetap
package MODUL4;
import java.awt.Color;
import java.awt.Container;
import javax.swing.*;

public class CobaAbsolutPosition extends JFrame  {
    
    private static final int FRAME_WIDHT        =300;
    private static final int FRAME_HEIGHT       =220;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_WIDTH       =80;
    private static final int BUTTON_HIGHT       =30; 
    private boolean running = true;
    private JTextField text;;
    private JButton cencelButton;
    private JButton okButton;
    
     public static void main(String[] args) {
       CobaAbsolutPosition f4 = new CobaAbsolutPosition();
        f4.setVisible(true);
    }
     public CobaAbsolutPosition(){
     
     Container contentpane = getContentPane();
     
      //set the frame properties
        setSize     (FRAME_WIDHT,FRAME_HEIGHT  );
        this.setResizable(false);
        setTitle    ("CobaAbsolutPosition");
        setLocation (FRAME_X_ORIGIN ,FRAME_Y_ORIGIN);
        
        // set the pane properties
        contentpane.setLayout(null);
        contentpane.setBackground(Color.white);
        

        
        //create and place two buttons on the frame's content pane
        okButton = new JButton("OK");
        okButton.setBounds(170, 135,BUTTON_WIDTH ,BUTTON_HIGHT );
        contentpane.add(okButton);
        
        cencelButton = new JButton("CANCEL");
        cencelButton.setBounds(50, 105,BUTTON_WIDTH  ,BUTTON_HIGHT);
        contentpane.add(cencelButton);
        
        // register 'Exit upon closing' as a default close operation
        setDefaultCloseOperation( EXIT_ON_CLOSE);
     }

   
    }

