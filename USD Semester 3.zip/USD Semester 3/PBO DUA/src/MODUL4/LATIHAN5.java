

package MODUL4;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class LATIHAN5 extends JFrame {
   
    private static final int FRAME_WIDTH        = 300;
    private static final int FRAME_HEIGHT       = 250;
    private static final int FRAME_X_ORIGIN     = 150;
    private static final int FRAME_Y_0RIGIN     = 250;
    private JList list;
    
    public static void main(String[] args) {
        LATIHAN5  frame = new LATIHAN5();
        frame.setVisible(true);
    }
    public LATIHAN5(){
        Container   contenpane;
        JPanel      listPanel, okPanel;
        JButton     okButton;
        String []   names = {"Ape","Bat","Bee", "Cat",
                            "Dog","-Eel","Fox","Gnu",
                            "Hen","Men","Sow","Yak"};
        
        setSize     (FRAME_WIDTH,FRAME_HEIGHT );
        setTitle    ("LATIHAN5 BRO");
        setLocation (FRAME_X_ORIGIN,FRAME_Y_0RIGIN);
        contenpane = getContentPane();
        contenpane.setBackground(Color.white);
        contenpane.setLayout(new BorderLayout());
        
        
        listPanel = new JPanel(new GridLayout(0,1));
        listPanel.setBorder(BorderFactory.createTitledBorder("therw-late Animal Name"));
        
        list = new JList(names);
        listPanel.add(new JScrollPane(list));
        
        
        okPanel = new JPanel(new FlowLayout());
        okButton = new JButton("OK");
        okPanel.add(okButton);
        
        contenpane.add(listPanel,BorderLayout.CENTER);
        contenpane.add(okPanel,BorderLayout.SOUTH);
        
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
    
}
