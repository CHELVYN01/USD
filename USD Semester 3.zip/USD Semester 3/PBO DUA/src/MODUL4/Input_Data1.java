// menampilkan frame dengan posisi yang tetap
package MODUL4;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;


public class Input_Data1 extends JFrame  {
    
    private static final int FRAME_WIDHT        =400;
    private static final int FRAME_HEIGHT       =400;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_TEXT_WIDTH  =200;
    private static final int BUTTON_BUTTON_WIDTH=80;
    private static final int BUTTON_WIDTH       =100;
    private static final int BUTTON_HIGHT       =20; 
    private boolean running = true;
    private JTextField text;;
    private JButton cencelButton;
    private JButton okButton;
    
     public static void main(String[] args) {
        Input_Data1 f4 = new Input_Data1();
        f4.setVisible(true);
    }
     public Input_Data1(){
     
     Container contentpane = getContentPane();
     
      //set the frame properties
        setSize     (FRAME_WIDHT,FRAME_HEIGHT  );
        this.setResizable(false);
        setTitle    ("input data");
        setLocation (FRAME_X_ORIGIN ,FRAME_Y_ORIGIN);
        
        // set the pane properties
        contentpane.setLayout(null);
        contentpane.setBackground(Color.white);
        
       // label taxt
        JLabel label1 = new JLabel("nama :");
        text = new JTextField(" ");
        label1.setBounds(20, 20, BUTTON_WIDTH, BUTTON_HIGHT);
        text.setBounds(120, 20,BUTTON_TEXT_WIDTH, BUTTON_HIGHT);
        contentpane.add(label1);
        contentpane.add(text);
        
        //label pilihan laki laki dan perempuan 
        JLabel label2 = new JLabel("jenis kelamin :");
        JRadioButton button = new JRadioButton("laki - laki");
        JRadioButton button1 = new JRadioButton("perempuan");
        ButtonGroup bg = new ButtonGroup();
        bg.add(button);
        bg.add(button1);
        
        label2.setBounds(20, 60,BUTTON_WIDTH, BUTTON_HIGHT);
        button.setBounds(120, 60,BUTTON_WIDTH, BUTTON_HIGHT);
        button1.setBounds(240, 60,BUTTON_WIDTH, BUTTON_HIGHT);
        contentpane.add(button1);
        contentpane.add(label2);
        contentpane.add(button);
        
        //pilhan hobi
         JLabel label3 = new JLabel("Hobi :");
         JCheckBox jb = new JCheckBox("olah raga");
         JCheckBox jb1 = new JCheckBox("Shopping");
         JCheckBox jb3 = new JCheckBox("Computer Game");
         JCheckBox jb4 = new JCheckBox("nonton Bioskop");
         label3.setBounds(20, 100,BUTTON_WIDTH, BUTTON_HIGHT);
         jb.setBounds(120, 100,BUTTON_WIDTH, BUTTON_HIGHT);
         jb1.setBounds(120, 130,BUTTON_WIDTH, BUTTON_HIGHT);
         jb3.setBounds(120, 160,BUTTON_TEXT_WIDTH, BUTTON_HIGHT);
         jb4.setBounds(120, 190,BUTTON_TEXT_WIDTH, BUTTON_HIGHT);
         contentpane.add(label3);
         contentpane.add(jb);
         contentpane.add(jb1);
         contentpane.add(jb3);
         contentpane.add(jb4);
         
        
    
        
        //create and place two buttons on the frame's content pane
        okButton = new JButton("OK");
        okButton.setBounds(101, 270,BUTTON_BUTTON_WIDTH ,BUTTON_HIGHT );
        contentpane.add(okButton);
        
        cencelButton = new JButton("CANCEL");
        cencelButton.setBounds(211, 270,BUTTON_BUTTON_WIDTH ,BUTTON_HIGHT);
        contentpane.add(cencelButton);
        
        // register 'Exit upon closing' as a default close operation
        setDefaultCloseOperation( EXIT_ON_CLOSE);
     }

   
    }

