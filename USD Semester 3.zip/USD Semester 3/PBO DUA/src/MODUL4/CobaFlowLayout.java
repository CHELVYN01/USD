// tampilan frame menggunakan FlowLayout
package MODUL4;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class CobaFlowLayout extends JFrame  {
    
    private static final int FRAME_WIDHT        =300;
    private static final int FRAME_HEIGHT       =200;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    
    public static void main(String[] args) {
        CobaFlowLayout fl = new CobaFlowLayout();
        fl.setVisible(true);
    }
    public CobaFlowLayout(){
        Container contentpane ;
        JButton button1,button2,button3,button4,button5;
        
        //set the frame properties
        setSize     (FRAME_WIDHT,FRAME_HEIGHT  );
        setTitle    ("coba menggunakan FlowLayoutManager");
        setLocation (FRAME_X_ORIGIN ,FRAME_Y_ORIGIN);
        
        contentpane = getContentPane();
        contentpane.setBackground(Color.white);
        FlowLayout flowlay = new FlowLayout();
        contentpane.setLayout(flowlay);
        
        //crate and place four button on the content pane
        button1 = new JButton("button 1");
        button2 = new JButton("button 2");
        button3 = new JButton("button 3");
        button4 = new JButton("button 4");
        button5 = new JButton("button 5");
        
        contentpane.add(button1);
        contentpane.add(button2);
        contentpane.add(button3);
        contentpane.add(button4);
        contentpane.add(button5);
        
        setDefaultCloseOperation( EXIT_ON_CLOSE);
        
        
        
    }
}
