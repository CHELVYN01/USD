
// menampilkan menu pada frame
package MODUL4;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class JFrameMenu extends JFrame{
    
    public static void main(String[] args) {
        JFrameMenu jm = new JFrameMenu();
        jm.setVisible(true);
    }
    
public JFrameMenu (){
    Container contentpane;
    
    setTitle        ("JFrameMenu");
    setSize         (600,400);
    setResizable    (false);
    setLocation     (10,10);
    
    contentpane = getContentPane();
    contentpane.setBackground(Color.cyan);
    
    JMenuBar mb = new JMenuBar();
    
    JMenu file = new JMenu("file");
    JMenuItem item1 = new JMenuItem("baru");
    JMenuItem item2 = new JMenuItem("simpan");
     
   file.add(item1);
   file.add(item2);
   
    JMenu file2 = new JMenu("file");
    JMenuItem item3 = new JMenuItem("baru");
    JMenuItem item4 = new JMenuItem("simpan");
     
    file2.add(item3);
    file2.add(item4);
    
    mb.add(file);
    mb.add(file2);
    
    this.setJMenuBar(mb);
    
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
