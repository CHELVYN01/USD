//kelvin keden

package MODUL2;

public class UKM {
 private String namaUnit;
 private Mahasiswa ketua;
 private Mahasiswa sekertaris;
 private Masyarakat[] anggota;
 
 

 public UKM(){
     
 }

    public UKM(String namaUnit) {
        this.namaUnit = namaUnit;
    }

    public String getNamaUnit() {
        return namaUnit;
    }

    public void setNamaUnit(String namaUnit) {
        this.namaUnit = namaUnit;
    }

    public Mahasiswa getKetua() {
        return ketua;
    }

    public void setKetua(Mahasiswa ketua) {
        this.ketua = ketua;
    }

    public Mahasiswa getSekertaris() {
        return sekertaris;
    }

    public void setSekertaris(Mahasiswa sekertaris) {
        this.sekertaris = sekertaris;
    }

    public Masyarakat[] getAnggota() {
        
        return anggota;
    }

    public void setAnggota(Masyarakat[] anggota) {
        this.anggota = anggota;
    }
    

    }
 

