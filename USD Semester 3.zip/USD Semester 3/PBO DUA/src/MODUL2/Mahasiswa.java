
package MODUL2;
   class Mahasiswa extends Penduduk {
   private String nim;
   
   public Mahasiswa(){
       
   }
   public Mahasiswa(String nim) {
        this.nim = nim;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }
   
   public double hitungluran(){
       return Double.parseDouble(getNim())/10000;
   }
   public String getKonsumsi(){
      return "snack, makan siang dan makan malam";
   }
   public String getFasilitas(){
       return "block note , alat tulis , dan leptop";
   }
   
    public String jenisSertivikat(){
        return "sertifikat panitia";
   
}
    


}

