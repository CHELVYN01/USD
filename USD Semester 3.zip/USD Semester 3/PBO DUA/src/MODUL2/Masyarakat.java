

package MODUL2;

public class Masyarakat extends Penduduk {
 private String nomor;
 
 public Masyarakat(){
 }
 public Masyarakat(String nomor) {
        this.nomor = nomor;
    }

    public String getNomor() {
        return nomor;
    }

    public void setNomor(String nomor) {
        this.nomor = nomor;
    }
  public double  hitungluran(){
    return Double.parseDouble(getNomor())*100;
  }
  public String getKonsumsi(){
      return "snack dan makan siang";
   }
   public String getFasilitas(){
       return "block note , alat tulis , dan modul pelatihan";
   }
   
    public String jenisSertivikat(){
        return "sertifikat peserta";
}
    
  
}
