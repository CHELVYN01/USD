
package MODUL2;

import java.util.Scanner;


public class tes {

    public static void main(String[] args) {
   Scanner k = new Scanner(System.in);
   double total = 0, total1 = 0;   
//   nama unit
      UKM um = new UKM();
      um.setNamaUnit("sejaterah");
      
//      panitia
      Mahasiswa ketua = new Mahasiswa("kelvin kleden");
      Mahasiswa seketeris = new Mahasiswa("karin kleden");
      um.setKetua(ketua);
      um.setSekertaris(seketeris);
      
      
      
      //anggota
        System.out.print("jumlah anggota :");
        int msh = k.nextInt();
        Masyarakat[] anggota = new Masyarakat[msh];
      for (int i = 0; i < anggota.length;i ++){
          System.out.println("\t");
          System.out.println("masukan anggota ke -"+(i+1));
          System.out.println("\t");
          System.out.print("masukan nama: ");
          String nama = k.next();
          System.out.print("masukan nomor: ");
          String nomor = k.next();
          anggota[i] = new Masyarakat(nomor);
          anggota[i].setNama(nama);
         total += anggota[i].hitungluran();
      }
        System.out.println("\t");
        
        System.out.println("nama unit :"+um.getNamaUnit());
        System.out.println("nama ketua :"+um.getKetua().getNim());
        System.out.println("jenis sertifikat :"+um.getKetua().jenisSertivikat());
        System.out.println("fasislita :"+um.getKetua().getFasilitas());
        System.out.println("Konsumsi : "+um.getKetua().getKonsumsi());
        System.out.println("\t");
        System.out.println("nama seksertaris :"+um.getSekertaris().getNim());
        System.out.println("jenis sertifikat :"+um.getSekertaris().jenisSertivikat());
        System.out.println("fasilitas :"+um.getSekertaris().getFasilitas());
        System.out.println("Konsumsi : "+um.getSekertaris().getKonsumsi());
        System.out.println("\t");
        for (int i = 0; i < anggota.length; i++){
             System.out.println("data anggota yang ke - "+(i+1));
             System.out.println("nama :"+anggota[i].getNama());
             System.out.println("luran :"+anggota[i].hitungluran());
             System.out.println("jenis sertifikat: "+anggota[i].jenisSertivikat());
             System.out.println(" fasilitas : "+anggota[i].getFasilitas());
             System.out.println("Konsumsi : "+anggota[i].getKonsumsi());
             System.out.println("\t");
        }  
        System.out.println("\t");
        
         System.out.println("total luran = "+total);
      }
      
}  
      
       
  