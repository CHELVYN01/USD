//kelvin kleden

package MODUL2;


interface   Peserta {
    
    public String jenisSertivikat();
    public String getFasilitas();
    public String getKonsumsi();
       
    
    
}
