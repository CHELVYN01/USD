
package MODUL10;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class ProgramJDBC {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("PROGRAM LATIHAN JDBC");
        System.out.println("====================");
        
        System.out.println("mencoba membuat koneksi ke database");
        ProgramJDBC p = new ProgramJDBC();
        Connection conn = p.getConnection();
        
        try {
            conn.close();
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
        
        System.out.println("Menu :");
        System.out.println("1. Lihat isi table ");
        System.out.println("2. Tambah Data ");
        System.out.println("3. Hapus Data ");
        System.out.println("4. update Data ");
        System.out.println("5. keluar ");
        int input = 0;
        while (input != 5){
            System.out.print("pilih menu ? :");
            input = sc.nextInt();
            switch (input){
                case 1:
                    p.showData();
                    break;
                case 2:
                    p.inputData();
                    break;
                case 3:
                    p.hapusData();
                    break;
                case 4:
                    p.updateData();
                    break;
                default :
                    break;
            }
        }
    }
    //latihan 1
    public Connection getConnection(){
        String host = "localhost";
        String port = "1521";
        String db = "xe";
        String usr = "hr";
        String pwd = "hr";
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
        
        }  catch(ClassNotFoundException ex){
            System.out.println("Maaf, driver class tidak ditemukan");
            System.out.println(ex.getMessage());
                  
    }
       //hubungkan ke sumber data 
       Connection conn = null;
       try{
           conn = DriverManager.getConnection("jdbc:oracle:thin:@"+host+":"+port+":"+db,usr,pwd);
       }
       catch (SQLException ex){
           
           System.out.println("maaf koneksi tidak berhasil");
            System.out.println(ex.getMessage());
       }
       
       if(conn != null){
           System.out.println("koneksi ke database berhasil terbentuk");
       }else{
           System.out.println("maaf, koneksi ke dalam database gagal terbentuk");
       }
       return conn;
       }
    //latihan 2
    public void showData(){
        Connection conn = null;
        Statement st = null;
        ResultSet rd = null;
        
        conn = this.getConnection();
        
        try{
            st = conn.createStatement();
            rd = st.executeQuery("select * from table_mahasiwa");
            
//            System.out.println("NIM\t\tNama\tIPK");
            while(rd.next()){
                System.out.println("NIM :"+rd.getString(1));
                System.out.println("NAMA :"+rd.getString(2));
                System.out.println("IPK :"+rd.getString(3));
               // System.out.println(rd.getString(1)+"1"+"\t"+rd.getString(2)+"\t"+rd.getString(3));
            }
        }
        catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
        finally{
            try{
                rd.close();
                st.close();
                conn.close();
                
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
    }
    //latihan 3
    public void inputData(){
        Connection conn = null;
        PreparedStatement ps = null;
        
        conn = this.getConnection();
        
        Scanner sy = new Scanner(System.in);
        System.out.println("INPUT DATA");
        System.out.print("MASUKAN NIM :");
        String nim = sy.nextLine();
        System.out.print("MASUKAN NAMA :");
        String nama = sy.nextLine();
        System.out.print("MASUKAN IPK :");
        double ipk = sy.nextDouble();
        
        try{
            ps = conn.prepareStatement("insert into table_mahasiwa values (?,?,?)");
            ps.setString(1, nim);
            ps.setString(2, nama);
            ps.setDouble(3, ipk);
            ps.executeUpdate();
            conn.commit();
            System.out.println("data suadah ditambahkan ");
            
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        finally{
            try {
                ps.close();
                conn.close();
            }
            catch (SQLException ex){
            System.out.println(ex.getMessage());
            }
        }
    }
    // latihan 4
   
         public void hapusData(){
            Connection conn = null;
            PreparedStatement ps = null;
            
            conn = this.getConnection();
            
            Scanner sc = new Scanner(System.in);
            System.out.println("DELETE DATA");
            System.out.println("Masukan Nim yang Akan Dihapus:");
            String nim = sc.next();
            
            try{
                ps = conn.prepareStatement("Delete from table_mahasiwa where nim = ?");
                ps.setString(1, nim);
                ps.executeUpdate();
                conn.commit();
                System.out.println("Data Sudah Dihapus");
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }finally{
            try{
                ps.close();
                conn.close();
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        }
    
    public void updateData(){
        Connection conn = null;
        PreparedStatement px = null;
        conn = this.getConnection();
        Scanner kel = new Scanner(System.in);
        System.out.println("UPDATE DATA");
        System.out.print("Masukan NIM yang akan di Update :");
        String nim = kel.next();
        System.out.print("Masukan koreksi nama :");
        String nama = kel.next();
        System.out.print("Masukan koreksi ipk :");
        double ipk = kel.nextDouble();
        try {
             px = conn.prepareStatement("update table_mahasiwa set nama = ?,ipk = ? where nim = ?");
            px.setString(1, nama);
            px.setDouble(2, ipk);
            px.setString(3, nim);
            px.executeUpdate();
            conn.commit();
            System.out.println("data suadah update ");
        }
            catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                px.close();
                conn.close();
            }catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        
        }
    }
    
}

