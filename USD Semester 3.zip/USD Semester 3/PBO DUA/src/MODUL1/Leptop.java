/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MODUL1;

public class Leptop extends Gedget {
 private String hardisk;
 private int jumlahUSB;

    public String getHardisk() {
        return hardisk;
    }

    public void setHardisk(String hardisk) {
        this.hardisk = hardisk;
    }

    public int getJumlahUSB() {
        return jumlahUSB;
    }

    public void setJumlahUSB(int jumlahUSB) {
        this.jumlahUSB = jumlahUSB;
    }
 
  
}
