/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MODUL1;

public class Mahasiswa {
    private String nim;
    private String nama;
    private Handphone handphone;
    private Tablet tablet ;
    private Leptop leptop;

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public Handphone getHandphone() {
        return handphone;
    }

    public void setHandphone(Handphone handphone) {
        this.handphone = handphone;
    }

    public Tablet getTablet() {
        return tablet;
    }

    public void setTablet(Tablet tablet) {
        this.tablet = tablet;
    }

    public Leptop getLeptop() {
        return leptop;
    }

    public void setLeptop(Leptop leptop) {
        this.leptop = leptop;
    }
    
    
    
}
