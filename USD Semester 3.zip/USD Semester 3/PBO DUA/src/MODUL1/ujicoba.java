
package MODUL1;
import java.util.Scanner;

public class ujicoba {
    public static void main(String[] args) {
     Scanner k = new Scanner (System.in);
        Mahasiswa mh = new Mahasiswa();
       mh.setNama("Blasius Chelvyn Kera KLeden"); 
       mh.setNim("205314117");
        
        System.out.println("\t");
        
        Handphone hp = new Handphone();
        hp.setMerk("Asus");
        hp.setWarna("Putih");
        hp.setProsesor("Intel Atom Z3560");
        hp.setRam("2 GB");
        hp.setRom("16 GB");
        hp.setKonektivitas("GSM,HSPA,LTE");
        
        System.out.println("\t");
        
        Tablet tb = new Tablet();
       tb.setMerk("Samsung");
        tb.setWarna("Hitam");
        tb.setProsesor("Marvel 1 PXA1088");
        tb.setRam("1,5 GB");
        tb.setRom("8 GB");
        tb.setKonektivitas("Wifi");
       
        
        System.out.println("\t");
        
        Leptop lp = new Leptop();
        lp.setMerk("Lenovo");
        lp.setWarna("Hitam");
        lp.setProsesor("Core 2 Duo 2.53 GHz");
        lp.setRam("2 GB");
        lp.setHardisk("160 GB");
        lp.setJumlahUSB(3);
 
        System.out.println("Nama : \t"+ mh.getNama());
        System.out.println("nim  : \t"+ mh.getNim());
        
        System.out.println("\t");
        
        System.out.println("Handphone");
        System.out.println( "merek :"+ hp.getMerk());
        System.out.println("warna :"+ hp.getWarna());                   
        System.out.println("prosesor :"+ hp.getProsesor()); 
        System.out.println("ram :" +hp.getRam());
        System.out.println("rom :" + hp.getRom());
        System.out.println("konektivitas :" +hp.getKonektivitas());
      
        System.out.println("\t");
        
        System.out.println("Tablet");
        System.out.println( "merek :"+ tb.getMerk());
        System.out.println("warna :"+ tb.getWarna());                   
        System.out.println("prosesor :"+ tb.getProsesor()); 
        System.out.println("ram :" +tb.getRam());
        System.out.println("rom :" + tb.getRom());
        System.out.println("konektivitas :" +tb.getKonektivitas());
        
        System.out.println("\t");
        
        System.out.println("Leptop");
        System.out.println( "merek :"+ lp.getMerk());
        System.out.println("warna :"+ lp.getWarna());                   
        System.out.println("prosesor :"+ lp.getProsesor()); 
        System.out.println("ram :" +lp.getRam());
        System.out.println("Hardisk :" + lp.getHardisk());
        System.out.println("konektivitas :" +lp.getJumlahUSB()+"buah");
      
      
        
        
       
        
        
      
        
    }
  
}
