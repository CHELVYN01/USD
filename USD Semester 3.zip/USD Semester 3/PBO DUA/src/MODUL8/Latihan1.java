

package MODUL8;

import java.util.Scanner;

public class Latihan1 {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("karakter-1 : ");
        String k1 = sc.next();
        System.out.print("karakter-2 : ");
        String k2 = sc.next();
        
        if(k1.compareTo(k2)>0){
            System.out.println("karakter pertama lebih besar dari karakter kedua");
        }
        else if(k1.compareTo(k2)<0){
            System.out.println("karakter pertama lebih kecil dari karakter kedua");
        }
        else {
            System.out.println("kedua karakter adalah sama");
        }
    }
}
