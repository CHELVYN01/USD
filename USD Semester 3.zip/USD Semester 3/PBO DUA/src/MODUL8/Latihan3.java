/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MODUL8;

public class Latihan3 {
    public static void main(String[] args) {
        String letters = "selamat hari ulang tahun, semoga panjang umur";
        
        //tes substring method
        System.out.printf("substring dari index 20 sampai terakhir adalah \"%s\"\n"
                ,letters.substring(20));
        System.out.printf("%s\"%s\"\n",
                "substring dari index 3 sampai 6, TETAPI index 6 tidak termasuk adalah",
                letters.substring(3,6));
    }
}
