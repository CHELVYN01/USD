

package MODUL8;

import java.util.Scanner;

public class Latihan5 {
   
    public static void main(String [] kelvin){
        Scanner sc = new Scanner(System.in);
        
        System.out.print("input :");
        String input = sc.next();
        String result = input.replaceAll("[aiueo]", "#");
        System.out.println("Output :"+result);
    }
}
