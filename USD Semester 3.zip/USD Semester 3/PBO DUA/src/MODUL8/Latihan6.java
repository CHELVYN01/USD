
package MODUL8;

import java.util.Scanner;

public class Latihan6 {
  
    public static void main (String[] kelvin){
        Scanner kel = new Scanner(System.in); 
        
        System.out.print("input kata :");
        String inp = kel.next();
     inp = inp.replaceAll("a", "4");
     inp = inp.replaceAll("i", "1");
     inp = inp.replaceAll("u", "11");
     inp = inp.replaceAll("e", "3");
     inp = inp.replaceAll("o", "0");
        System.out.println("output :"+inp);
    }
    
}
