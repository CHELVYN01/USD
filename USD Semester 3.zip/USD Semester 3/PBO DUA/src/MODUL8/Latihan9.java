

package MODUL8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Latihan9 {
    
    public static void main(String[] kelvin) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Masukan sebuah kalimat :");
        String sentence = sc.nextLine();
        
        StringTokenizer tokens = new StringTokenizer(sentence);
        
        System.out.println("Kalimat anda terdiri dari kata - kata berikut ini :");
        while (tokens.hasMoreElements()){
            System.out.println(tokens.nextToken());
        }
    }
}
