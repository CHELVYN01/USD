
package MODUL8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Latihan10 {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Masukan kalimat :");
        String kalimat = sc.nextLine();
         StringTokenizer token = new StringTokenizer(kalimat);
          String hasil = null;
          hasil += kalimat;
         
          
        System.out.println("Jumlah kata :");
        while(token.hasMoreTokens()){
            System.out.println(token.countTokens()+" kata");
            break;
        }
            
    }
}
