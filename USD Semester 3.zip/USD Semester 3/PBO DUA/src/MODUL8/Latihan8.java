

package MODUL8;

import java.util.Scanner;

public class Latihan8 {
   
    public static void main(String[] kelvin){
        
        String poli = "";
        Scanner kel = new Scanner(System.in);
        StringBuffer data = new StringBuffer();
       
        System.out.print("input kata :" );
         String inp1 = kel.next();
         data.append(inp1);
         
        System.out.println("Reverse Kata :"+data.reverse());
        
        int polindrom = inp1.length();
        for(int i = polindrom - 1; i>=0; i--){
         poli = poli + inp1.charAt(i);
        }
       if(inp1.equals(poli)){
           System.out.println("Status : Polindrom");
       }
       else{
           System.out.println("Status bukan : polindrom");
           System.out.println("\t");
          
          
       
       }
        }
    }
  

