
package MODUL8;

import javax.swing.JOptionPane;

public class Latihan2 {
    
   private static final char BLANK  = ' ';
   
    public static void main(String[] args) {
        int index, wordcount,numberOfCharacter;
        
        String sentence = JOptionPane.showInputDialog("input kalimat");
        
        numberOfCharacter   = sentence.length();
        index               = 0;
        wordcount           = 0;
        
        while (index < numberOfCharacter  ){
            //abaikan spasi kosong
            while(index < numberOfCharacter && sentence.charAt(index)
                    == BLANK){
            index ++;
        }
        while(index < numberOfCharacter && sentence.charAt(index)
                    != BLANK){
            index ++;
        }
        wordcount++;  
          
        }
        
        System.out.println("\nInput sentence :"+sentence);
        System.out.println("wordcount :"+ wordcount + " word");
    }
    
}
