
package MODUL8;
import java.util.Scanner;
public class Latihan7 {
    public static void main(String[] kelvin){
        Scanner kel = new Scanner(System.in);
        StringBuffer data = new StringBuffer();
      
        System.out.print("first name :" );
         String inp1 = kel.nextLine();
        System.out.print("Middlename :");
         String inp2 = kel.nextLine();
        System.out.print("Middlename2 :");
         String inp3 = kel.nextLine();
        System.out.print("Lastname :");
         String inp4 = kel.nextLine();
    
        data.append(inp1);
        data.append(" ");
        data.append(inp2);
        data.append(" ");
        data.append(inp3);
        data.append(" ");
        data.append(inp4);
        data.append(" ");
      
        System.out.println("FullName :"+data+"  ");
          
            
           
       
    }
}
