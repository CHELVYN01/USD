
package MODUL3;

import javax.swing.JFrame;

public class KELVIN {
  
    
   
   
    public static void main(String[] args) {
        JFrame frame = new JFrame("ini framee pertamaku");
        
        int tinggi = 100;
        int lebar = 200;
        
        frame.setBounds(100, 500, lebar, tinggi);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    
}
   