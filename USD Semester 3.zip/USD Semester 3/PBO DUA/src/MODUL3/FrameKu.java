

package MODUL3;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class FrameKu extends JFrame  {
    
    public FrameKu(){
        this.setSize(400, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("\t        FIND        \t");
        this.setVisible(true);
        
        
        JLabel label = new JLabel();
        JTextField text = new JTextField();
        JCheckBox box = new JCheckBox();
        JRadioButton radio = new JRadioButton();
        JPanel panel = new JPanel();
        JButton tombol = new JButton();
        text.setText("                                                         ");
        
        tombol.setText("FIND");
        label.setText("FIND");
        panel.add(label);
        panel.add(radio);
        panel.add(text);
        panel.add(tombol);
        panel.add(box);
        this.add(panel);
        
        
   
        
      
        
    }
    public static void main(String[] args) {
        new FrameKu();
    }

}
