//soal 4 menampilkan tampilan nomor 4 pada modul latihan Graphical User Interface
package MODUL3.latihan4;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FrameKu extends JFrame {
    
    public FrameKu(){
        this.setSize(400, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("\t        FIND        \t");
        this.setVisible(true);
        
        JLabel label = new JLabel();
        JTextField text = new JTextField();
        JButton tombol = new JButton();
        JPanel panel = new JPanel();
        
        label.setText("Keyword :");
        text.setText("                                                         ");
        tombol.setText("FIND");
        panel.add(label);
        panel.add(text);
        panel.add(tombol);
        this.add(panel);
    }
    public static void main(String[] args) {
        new FrameKu();
    }
}