//soal 2 menampilkan title
package MODUL3.latihan2;

import javax.swing.JFrame;

public class FrameKu extends JFrame {
     public FrameKu(){
        this.setSize(400, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("ini class turunan dari class JFrame");
        this.setVisible(true);
        
     }
      public static void main(String[] args) {
        new FrameKu();
    }
}
