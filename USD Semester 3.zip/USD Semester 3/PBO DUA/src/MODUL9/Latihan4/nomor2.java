
package MODUL9.Latihan4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JFileChooser;


public class nomor2 {
    public static void main(String[] args) throws IOException {
        
    
    Scanner sc = new Scanner(System.in);
    
    JFileChooser chooser = new JFileChooser();
    int status = chooser.showSaveDialog(null);
    if(status == JFileChooser.APPROVE_OPTION ){
       
        System.out.println("Masukan Pesan :"); 
        String pesan = sc.nextLine();
        File simpan = chooser.getSelectedFile();
        
        try {
            FileWriter tp = new FileWriter(simpan.getPath());
            tp.write(pesan);
            tp.flush();
            tp.close();
            
        }
        catch (Exception ec){
            System.out.println("Error :" + ec.getMessage());
        }
        
    }

}
}