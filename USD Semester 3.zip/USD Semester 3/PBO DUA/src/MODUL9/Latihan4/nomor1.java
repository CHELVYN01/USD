

package MODUL9.Latihan4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class nomor1 {
    public static void main (String[] kelvn_kleden) throws IOException{
        
        FileOutputStream outStream = null;
        
        String info = " ayo berlatih Stream";
        
        File outFile = new File("ujicobaStream.txt");
        try{
            outStream = new FileOutputStream (outFile);
            outStream.write(info.getBytes());
            outStream.close();
        }catch (FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        }

        
        
    }
    
    
}
