

package MODUL9.Latihan3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFileChooser;

public class nomor3 {
    public static void main(String[] args) throws IOException {
         JFileChooser chose = new JFileChooser();
      
         int status = chose.showOpenDialog(null);
         if (status == JFileChooser.APPROVE_OPTION){
             
             try {
                 File baca = chose.getSelectedFile();
                 BufferedReader baca1 = new BufferedReader(new FileReader (baca.getPath()));
                 String line = " ";
                 String baca2 = " ";
                 while ((line = baca1.readLine())!= null){
                     baca2 += line;
                    
                 }
                 
                 System.out.println(baca2);
                 if(baca1 != null){
                     baca1.close();
                 }
             }catch (Exception ex){
                 System.out.println(ex.getMessage());
             }
             
         }
    }
 
}
