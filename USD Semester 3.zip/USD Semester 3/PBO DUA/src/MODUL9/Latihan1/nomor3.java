/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MODUL9.Latihan1;

import java.io.File;

public class nomor3 {
    public static void main(String[] args) {
        
    
    
      File file = new File("e:/sample.txt");
      if(!file.exists()){
            System.out.println("Maaf file tidak di temukan");
        }else{
            System.out.println("file ditemukan");
        }
}
}