

package MODUL9.Latihan1;

import java.io.File;

public class nomor1 {
    public static void main(String[] args) {
        
       File file = new File("semple.txt");
      
        if(!file.exists()){
            System.out.println("Maaf file tidak di temukan");
        }else{
            System.out.println("file ditemukan");
        }
    }     
}
