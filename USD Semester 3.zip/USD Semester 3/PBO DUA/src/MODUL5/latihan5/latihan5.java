 
package MODUL5.latihan5;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class latihan5 extends JFrame implements ActionListener {

    private static final int FRAME_WIDHT        =350;
    private static final int FRAME_HEIGHT       =400;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_WIDTH       =80;
    private static final int BUTTON_HIGHT       =30; 
    JTextField text1,text2, text3;
    JButton tombol;
    JLabel lkalkulator, label1,label2, label3;
    
    public static void main(String[] args) {
        latihan5 ls = new latihan5();
        ls.setVisible(true);
        
    }
    
    public latihan5(){
        Container contentpane = getContentPane();
        contentpane.setLayout(null);
        
        //set size
        this.setSize(FRAME_WIDHT, FRAME_HEIGHT);
        this.setResizable(false);
        this.setTitle("input data");
        this.setLocation(FRAME_X_ORIGIN , FRAME_Y_ORIGIN);
        
        //label 
        lkalkulator = new JLabel(" KALKULATOR +");
        label1 = new JLabel("Bilangan 1 :");
        label2 = new JLabel("Bilangan 2 :");
        label3 = new JLabel("HASIL      :");
        lkalkulator.setBounds(100, 20, 120  ,BUTTON_HIGHT);
        label1.setBounds(20, 60, 120  ,BUTTON_HIGHT);
        label2.setBounds(20, 120, 120  ,BUTTON_HIGHT);
        label3.setBounds(20, 180, 120  ,BUTTON_HIGHT);
       
        contentpane.add(label1);
        contentpane.add(label2);
        contentpane.add(label3);
        contentpane.add(lkalkulator);
        //textField
        text1 = new JTextField("");
        text2 = new JTextField("");
        text3 = new JTextField("");
        text1.setBounds(100, 60,120  ,BUTTON_HIGHT);
        text2.setBounds(100, 120,120  ,BUTTON_HIGHT);
        text3.setBounds(100, 180,120  ,BUTTON_HIGHT);
        contentpane.add(text1);
        contentpane.add(text2);
        contentpane.add(text3);
        
        // tombol
        tombol = new JButton("JUMLAH");
        tombol.setBounds(100, 240,100  ,BUTTON_HIGHT);
         contentpane.add(tombol);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        tombol.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    int hasil = 0;
    String angka1 = text1.getText();
    String angka2 = text2.getText();
    int ke1 = Integer.parseInt(angka1);
    int ke2 = Integer.parseInt(angka2);
    hasil = ke1 + ke2;
    text3.setText(""+hasil);
    
   
    }
    
    
    
}
