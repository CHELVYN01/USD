

package MODUL5.latihan1;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JRootPane;

public class ButtonHandler implements ActionListener{
    
    public ButtonHandler(){
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    JButton jb = (JButton) e.getSource();
    JRootPane  rp = jb.getRootPane();
    Frame frame = (JFrame) rp.getParent();
    String bt = jb.getText();
    
    frame.setTitle("you click: "+bt);
    
         }
    
}
