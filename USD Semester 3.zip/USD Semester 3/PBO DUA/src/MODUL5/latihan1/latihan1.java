//kelvin
package MODUL5.latihan1;
import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.*;
public class latihan1 extends JFrame {
    private static final int FRAME_WIDHT        =300;
    private static final int FRAME_HEIGHT       =220;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_WIDTH       =80;
    private static final int BUTTON_HIGHT       =30; 
    private JButton button;
    
     public static void main(String[] args) {
      latihan1 f4 = new latihan1();
      f4.setVisible(true);
     }
    public latihan1(){
        Container contentpane = getContentPane();
        contentpane.setLayout(new FlowLayout());
         //set the frame properties
        setSize     (FRAME_WIDHT,FRAME_HEIGHT  );
        this.setResizable(false);
        setTitle    ("CobaAbsolutPosition");
        setLocation (FRAME_X_ORIGIN ,FRAME_Y_ORIGIN);
        // button 
        button = new JButton("click me");
        button.setSize(BUTTON_WIDTH, BUTTON_HIGHT);
        contentpane.add(button);
        //Button Handler
        ButtonHandler br = new ButtonHandler();
        button.addActionListener(br);
        
        //exit
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}
}