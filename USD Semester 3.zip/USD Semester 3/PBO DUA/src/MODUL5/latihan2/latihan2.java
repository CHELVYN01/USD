//kelvin 205314117
package MODUL5.latihan2;
import MODUL5.latihan1.ButtonHandler;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JRootPane;

public class latihan2 extends JFrame implements ActionListener {
    private static final int FRAME_WIDHT        =300;
    private static final int FRAME_HEIGHT       =220;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_WIDTH       =80;
    private static final int BUTTON_HIGHT       =30; 
    private JButton button;
    
     public static void main(String[] args) {
      latihan2 f4 = new latihan2();
      f4.setVisible(true);
     }
    public latihan2(){
        Container contentpane = getContentPane();
        contentpane.setLayout(new FlowLayout());
        
        
         //set the frame properties
        setSize     (FRAME_WIDHT,FRAME_HEIGHT  );
        this.setResizable(false);
        setTitle    ("latihan2");
        setLocation (FRAME_X_ORIGIN ,FRAME_Y_ORIGIN);
        
        button = new JButton("click me");
        button.setSize(BUTTON_WIDTH, BUTTON_HIGHT);
        contentpane.add(button);
        button.addActionListener(this);
        
        //exit
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}

    @Override
    public void actionPerformed(ActionEvent e) {
    JButton jb = (JButton) e.getSource();
    JRootPane  rp = jb.getRootPane();
    Frame frame = (JFrame) rp.getParent();
    String bt = jb.getText();
    
    frame.setTitle("(dibuat dengan cara - 2)you clicked "+bt);
    }
}

//Algoritma action event
//	Memanggil JButton dan e.sourch untuk pengembalian button 
//	Memanggil JRootPane (mirip dengan JPanel tetapi objek ini menggunkan ContentPane)
//	Memannggil JFrame dan getParent (getPerent berfungsi untuk mengembalikan induk dari objek file yang di berikan dari JRootPane.
//	Membuat objek  dari jb(objeck JButton) dengan mengguanakan method getText yaitu bt
//	Membuat judul baru dari Frame, dengan objeck text yaitu bt
//
