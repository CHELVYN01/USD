

package MODUL5.latihan4;

import MODUL5.latihan1.ButtonHandler;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
;


public class latihan4 extends JFrame implements ActionListener  {
      private static final int FRAME_WIDHT        =300;
    private static final int FRAME_HEIGHT       =220;
    private static final int FRAME_X_ORIGIN     =150;
    private static final int FRAME_Y_ORIGIN     =250;
    private static final int BUTTON_WIDTH       =80;
    private static final int BUTTON_HIGHT       =30; 
    private JButton button, button2;
    private JTextField pesan;
    
     public static void main(String[] args) {
      latihan4 l4 = new latihan4();
      l4.setVisible(true);
     }
    public latihan4(){
        Container contentpane = getContentPane();
        contentpane.setLayout(new FlowLayout());
        
        
         
        //set the frame properties
        setSize(FRAME_WIDHT , FRAME_HEIGHT);
        setResizable(false);
        setTitle("Program Ch7JButtonFrame");
        setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);

        //create and place two buttons on the frame's content pane
        button = new JButton("Click Me");
        button.setSize(BUTTON_WIDTH, BUTTON_HIGHT);
        contentpane.add(button);
        button2 = new JButton("Tombol2");
        button2.setSize(BUTTON_WIDTH, BUTTON_HIGHT);
        contentpane.add(button2);
        button.addActionListener(this);
        button2.addActionListener(this);
        //pesan 
        pesan = new JTextField();
        pesan.setColumns(20);
        contentpane.add(pesan);
        //exit
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);}

    @Override
    public void actionPerformed(ActionEvent e) {
    JButton clickedButton = (JButton) e.getSource();
       JRootPane rootPane = clickedButton.getRootPane();
       Frame frame = (JFrame)rootPane.getParent();
       String buttonText = clickedButton.getText();
       if(buttonText.equals("Click Me")){
           String isiPesan = pesan.getText();
           frame.setTitle(isiPesan);
       }else{
           frame.setTitle("You clicked" + buttonText);
       }
       
    }
}


