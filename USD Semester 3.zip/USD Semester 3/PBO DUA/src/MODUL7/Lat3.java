
package MODUL7;

import java.util.Scanner;

public class Lat3 {
    public static void main(String[] args) {
        Scanner k = new Scanner (System.in);
        
        int bil1;
        int bil2;
        int hasil = 0;
        
        while (true){
            try{
            System.out.print("Masukan bilangan 1 :");
            String a = k.next();
            bil1 = Integer.parseInt(a);
            break;
            }
            catch (Exception e){
                System.out.println("terjadi kesalahan input, mohon di ulangi lagi");
            }
        }
        
        while (true){
            try{
                System.out.print("Masukan bilangan 2 :");
                String b = k.next();
                bil2 = Integer.parseInt(b);
                break;
            }
            catch (Exception e){
                System.out.println("terjadi kesalahan input, mohon di ulangi lagi");
            }
        }
        
        hasil = bil1 + bil2 ;
        System.out.println("Hasil penjumlahan kedua nilai itu : "+ hasil);
    }
}
