/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MODUL7;

import javax.swing.JOptionPane;

public class Lat2 {
   
    public static void main(String[] args) {
        String inputStr = JOptionPane.showInputDialog(null, "age :");
// latihan 3 non Exception Handling 
//        int age = Integer.parseInt(inputStr);
      int age = 0;
// latihan 3  Exception Handling      
    try {
            age = Integer.parseInt(inputStr);
    }
    catch  (NumberFormatException e)
    {
        System.out.println("Maaf input yang anda masukan salah");
    }
        
        System.out.println("Umur anda : "+age+"tahun");
    }
 
}
