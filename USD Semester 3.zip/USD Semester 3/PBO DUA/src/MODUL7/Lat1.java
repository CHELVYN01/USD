

package MODUL7;

import java.util.Scanner;

public class Lat1 {
    public static void main(String[] args) {
        Scanner k = new Scanner(System.in);
        
        System.out.print("Masukan jarak perjalasana anda (KM) :");
        int jarak = k.nextInt();
        System.out.print("Masukan banyaknya bensin yang dihabiskan (liter) :");
        int liter = k.nextInt();
        
      //  latihan 1
//        int konsumsi = jarak/liter;
//        
////      latihan 2
        int konsumsi = 0;
        try{
            konsumsi = jarak/liter;
        }
        catch(Exception e) {
            konsumsi = 0;
        }
        System.out.println("\t");
        System.out.println("Konsumsi BBM anda adalah "+ konsumsi+"km/liter");
    }
}
