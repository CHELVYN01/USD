

package latihan2;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class latihan1 extends JFrame implements ActionListener{
    private final int HEIGHT_FRAME = 400;
    private final int WIDTH_FRAME  = 300;
    private final int x = 80;
    private final int y = 20;
    
    private JButton clickButton;
    private JLabel klikLabel;
    private int nomberClicks ;
    
   public latihan1(){
    
     
      super("latihan1");
      this.setSize(HEIGHT_FRAME,WIDTH_FRAME);
      this.setLayout(new FlowLayout());
      this.setLocation(x, y);
      this.setResizable(false);
      
      klikLabel = new JLabel("number of button click"+getNomberClicks());
      clickButton = new JButton("i'm swing button");
      
    
      //tampilan 
      this.setSize(HEIGHT_FRAME,WIDTH_FRAME);
      this.setLayout(new FlowLayout());
      this.add(klikLabel);
      this.add(clickButton);
      
      
      //ukuran button dan label 
      
      
      
      //action even
      clickButton.addActionListener((ActionListener)this);
      
   }

    public int getNomberClicks() {
        return nomberClicks;
    }

    public void setNomberClicks(int nomberClicks) {
        this.nomberClicks = nomberClicks;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
       setNomberClicks(getNomberClicks()+1);
       klikLabel.setText("Number of button clicks: "+getNomberClicks());
       
        }
    public static void main(String[] args) {
     
       latihan1 gui = new latihan1();
       gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       gui.setVisible(true);
    
    }
    
}
