

package latihan2;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import latihan1.Latihan2;

public class latihan2 extends JPanel implements ActionListener {

    private JButton merah = new JButton("MERAH");
    private JButton hitam = new JButton("HITAM");
    private JButton kuning = new JButton("KUNING");
    
    latihan2(){
        add(merah);
        add(kuning);
        add(hitam);
        
        merah.addActionListener(this);
        kuning.addActionListener(this);
        hitam.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent kelvin) {
        Object warna = kelvin.getSource();
        Color color = this.getBackground();
        // mentest button warna 
        if (warna == merah)
            color = Color.RED;
          
        else if (warna == kuning)
            color = Color.YELLOW;
          
        else if (warna == hitam )
            color = Color.BLACK;
            
       this.setBackground(color);
       this.repaint();
         }
   
    public static void main(String[] args) {
        JFrame fm = new JFrame("tampil warna");
        fm.setSize(300,200);
        fm.addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent k){
            System.exit(0);
        }});
         Container contentPane = fm.getContentPane();
         contentPane.add(new latihan2());

    fm.show();
  }
    }
    

