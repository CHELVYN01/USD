package QueueDinamis;


public class QueueDinamis {
    public static void main(String[] args) {
        Queue antrian = new Queue();
        antrian.enqueue(26);
        antrian.enqueue(15);
        antrian.enqueue(8);
        antrian.enqueue(14);
        
        System.out.println("Antrian yang dikeluarkan " + antrian.dequeue()); 
        System.out.println("Antrian yang dikeluarkan " + antrian.dequeue());
        
        antrian.cetak();
    }
}
