/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sdl3;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class main {
    public static void main(String[] args) {
        Scanner kel = new Scanner(System.in);
        boolean run = true;
        
        Pengelolahan q = new Pengelolahan();
        
        while(run){
            
            System.out.println("\n");
            System.out.println("====== SELAMAT DATA DI PERPUSTAKAAN KU =====");
            System.out.println("1. Masukan Data ");
            System.out.println("2. Hapus Data ");
            System.out.println("3. Cari data ");
            System.out.println("4. Tampilkan Data ");
            System.out.println("5. keluar ");
            
            System.out.print("Silakan masukan pilhan Anda :");
            int a = kel.nextInt();
            if(a == 1){
                System.out.print("nama Buku :");
                String nama = kel.next();
                System.out.print("penulis Buku :");
                String penulis = kel.next();
                System.out.print("Penerbit Buku : Pt");
                String penerbit = kel.next();
                
                buku bk = new buku(nama, penulis, penerbit);
                
                q.Tambah(bk);
                System.out.println("data  berhasil di tambhakan");
                
            }
            if (a==2){
                if(!q.isEmpty()){
                     buku temp = (buku) q.Hapus();
                     System.out.println("buku dengan rincian :"+temp+"telah di hapus dari antrian");
                     
                }else{
                    System.out.println("data antrian kosong");
                } 
                
            }
            if (a ==3){
                System.out.println("masukan judul buku :");
                String judul = kel.next();
                buku baru = new buku(judul);
                if(q.search(baru) == null){
                    System.out.println("buku tidak ada  ");
                }else{
                    System.out.println("buku ada   ");
                }
            }
            
            if(a==4){
                
                System.out.println("No  Judul Buku  Penulis  Penerbit"); 
                System.out.println("" + q.getAntrian().print() + "");
               
              
            }
            
            if (a == 5){
                run = false;
            }
        }
        
    }
    
}
