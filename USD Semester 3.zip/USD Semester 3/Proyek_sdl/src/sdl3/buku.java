/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sdl3;

/**
 *
 * @author HP
 */
public class buku  implements Comparable{

    private String nama;
    private String penulis;
    private String penerbit;
   
    
    public buku (String nama){
        this.nama = nama;
        
    }
    
    public buku (String nama, String penulis,String penerbit){
        this.nama = nama;
        this.penulis = penulis;
        this.penerbit = penerbit;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getPenulis() {
        return penulis;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    public String getPenerbit() {
        return penerbit;
    }

    public void setPenerbit(String penerbit) {
        this.penerbit = penerbit;
    }
    
    public String toString(){
        return nama + "\t" + penulis + "\t" + penerbit + "\n";
    }

    @Override
    public int compareTo(Object o) {
    return nama.compareTo(((buku)o).getNama());
    
    }
    
 
}
