package sdl3;

public class Pengelolahan {
    private LinkedList antrian;
    
    public Pengelolahan(LinkedList antrian) {
        this.antrian = antrian;
    }
    
   public  Pengelolahan (){
        antrian = new LinkedList();
    }
    
   public void Tambah (Object data){
        getAntrian().addLast(data);
    }
    public Object Hapus(){
        return getAntrian().removeFirst();
    }
    public int Size() {
        return getAntrian().getSize();
    }

    public boolean isEmpty() {
      return getAntrian().isEmpty();
    }
  public Object search(Object cari){
      return getAntrian().search(cari);
  }

    /**
     * @return the antrian
     */
    public LinkedList getAntrian() {
        return antrian;
    }
    
  }
