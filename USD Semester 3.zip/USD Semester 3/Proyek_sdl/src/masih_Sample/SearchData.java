
package masih_Sample;

import sdl1.buku;

public class SearchData {
    public static void cetak(Object[]q){
       for(int i =1; i < q.length; i++){
           System.out.println("ada di rak :"+i+""+ q[i]);
       }
    }
    public static int sequentialObject(buku[] p, buku key) {
        for (int i = 1; i < p.length - 1; i++) {
            if (((Comparable) p[i]).compareTo(key) == 0) {
                return i;
            }
        }
        return -1;
    }
    
}
