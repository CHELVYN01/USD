/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sdl1;

public class main {
    public static void main(String[] args) {
        buku[] bk = new buku[4];
        
        Stack st = new Stack();
        bk[1] = new buku("tidur","kelvin","PT Titus");
        bk[2] = new buku("imajinasi","virgy","PT Surya");
        bk[3] = new buku("pilek","kris","PT Kesehatan");
        st.cari(bk);
        
       // st.Push(bk[3]);
//        st.Pop();
//        
//   
    }
}