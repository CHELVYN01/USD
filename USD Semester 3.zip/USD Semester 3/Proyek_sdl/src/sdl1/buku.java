/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sdl1;

/**
 *
 * @author HP
 */
public class buku {
 
   private String nama_buku;
   private String penulis;
   private String penerbit;
   
   public buku (String nama_buku, String penulis,String penerbit){
       this.nama_buku = nama_buku;
       this.penulis = penulis;
       this.penerbit = penerbit;
       
       
   }

    public String getNama_buku() {
        return nama_buku;
    }

    public void setNama_buku(String nama_buku) {
        this.nama_buku = nama_buku;
    }

    public String getPenulis() {
        return penulis;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    public String getPenerbit() {
        return penerbit;
    }

    public void setPenerbit(String penerbit) {
        this.penerbit = penerbit;
    }
 
   public String toString(){
       return  "\nJudul Buku\t :"+ nama_buku+
               "\nPenulis\t\t :"+penulis+
               "\nPenerbit\t:"+penerbit+
               "\n";
       
       
   }
       
           
}
