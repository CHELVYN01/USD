/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sdl1;

import java.util.NoSuchElementException;

public class Stack {
   Object[] elemen;
   int front;
   int size;
   
   public Stack(){
       
   }
   
   public Stack(int ukuran){
       front = -1;
       elemen = new Object[ukuran];
       size = 0;
   }
   
   public Object Push(Object tambah){
       if (size < elemen.length){
           front = front + 1;
           elemen[front] = tambah;
           return true;
       }else {
           return false;
       }
       
   }
   
   public Object Pop (){
     if  (isEmpty()){
       Object temp = elemen[front];
       front = front -1;
       size --;
       return temp;
       
   }
       else{
               throw new NoSuchElementException();
               }
   }
   
   public int size(){
       return size;
       
  }
   public boolean isEmpty(){
       if(front == -1){
           return true;
       }else {
           return false;
       }
   }
      public  void cari(Object[]q){
       for(int i =1; i < q.length; i++){
           System.out.println("ada di rak :"+i+""+ q[i]);
       }
    }
    public void cetak() {
        for (int i = 0; i < size; i++) {
            System.out.print(elemen[i] +" ");
            System.out.print(elemen[i]);
                    
        }
        System.out.println("");
       
    }
}
