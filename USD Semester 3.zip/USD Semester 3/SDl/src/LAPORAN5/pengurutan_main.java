
package LAPORAN5;

import java.lang.reflect.Array;
import java.util.Arrays;

public class pengurutan_main  {
    public static void main(String[] args) {
         int[] larik ={23,56,45,12,67,86,43,66,99,25,61,5,78,76,33,63,5,8,15,20};
         System.out.println("larik sebelum di urut");
         for (int iterasi= 0; iterasi<larik.length; iterasi++){
             System.out.print(larik[iterasi]+" , ");
          Arrays.sort(larik);
             
         }
        System.out.println("\t");
        System.out.println("\t");
        System.out.println("larik sudah di urut menggunakan bubble sort");
        LARIK.BubleSort(larik);
         for (int iterasi= 0; iterasi<larik.length; iterasi++){
             System.out.print(larik[iterasi]+" , ");
         }
         System.out.println("\t");
         System.out.println("\t");
        System.out.println("larik sudah di urut menggunakan selection sort");
        LARIK.selectionSort(larik);
         for (int iterasi= 0; iterasi<larik.length; iterasi++){
             System.out.print(larik[iterasi]+" , "); 
         }
        System.out.println("\t");
        System.out.println("\t");
        System.out.println("larik sudah di urut menggunakan insert sort");
        LARIK.selectionSort(larik);
        for (int iterasi= 0; iterasi<larik.length; iterasi++){
           System.out.print(larik[iterasi]+" , ");    
          
         
         
         
}
}
}