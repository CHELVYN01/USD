package QueueStatis_Object;

/**
 *
 * @author LENOVO
 */
public class MainStatis {
    public static void main(String[] args) {
        Queue antrian = new Queue(7);
        antrian.enqueue(new Mahasiswa("Flora", 205314074, "Informatika", "Sulsel"));
        antrian.enqueue(new Mahasiswa("Lala", 205314071,  "Informatika", "Sumatra"));
        antrian.enqueue(new Mahasiswa("Ferby", 205314069, "Informatika", "KalBar"));
        antrian.enqueue(new Mahasiswa("Puput", 205314075, "Informatika", "KalTeng"));
        antrian.enqueue(new Mahasiswa("Jessi", 195314001, "Teologi", "Sulsel"));

        System.out.println("\nAntrian yang dikeluarkan " + antrian.dequeue()); 
        System.out.println("\nAntrian yang dikeluarkan " + antrian.dequeue()); 
        System.out.println("\nAntrian yang dikeluarkan " + antrian.dequeue()); 
        
        antrian.cetak();
    }
}
