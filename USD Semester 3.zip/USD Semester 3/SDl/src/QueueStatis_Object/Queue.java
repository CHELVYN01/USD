package QueueStatis_Object;

import java.util.NoSuchElementException;

/**
 *
 * @author LENOVO
 */
public class Queue {
    Object elemen[];
    int front = 0;
    int rear = 0;
    int size = 0;
    
     public Queue() {}
    
    public Queue(int ukuran) {
        elemen = new Object [ukuran];
    }
    
    boolean enqueue(Object data) {
        if (size < elemen.length) {
            elemen[rear] = data;
            if (rear == elemen.length - 1) {
                rear = 0;
            } else {
                rear++;
            }
            size++;
            return true;
        }
        return false;

    }

    Object dequeue (){
        if (elemen.length != 0){
            Object hapus = elemen[front];
            if (front == elemen.length - 1){
                front = 0;
            } else {
                front++;
            }
            size--;
            return hapus;
        }
        throw new NoSuchElementException();
    }
    public Object Size() {
        return size;
    }

    public boolean isEmpty() {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public void cetak(){
        for (int i = front; i < rear; i++) {
            System.out.println("" + elemen[i]);
        }
    }
}
