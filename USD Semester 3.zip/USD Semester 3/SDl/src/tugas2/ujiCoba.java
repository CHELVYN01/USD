/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tugas2;

public class ujiCoba {
   public static void main(String[] args) {
		MyArrayGrow kv = new MyArrayGrow(2);

		kv.addFront('a');		kv.addFront('b');
		kv.addRear('c');
		kv.addFront('t');
		kv.addRear('m');
		kv.addRear('q');
		kv.addFront('p');
		kv.addRear('t');
		kv.print();
	}
}