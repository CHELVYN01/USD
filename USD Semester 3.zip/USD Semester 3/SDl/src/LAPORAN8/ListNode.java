

package LAPORAN8;


    public class ListNode {
    public int elemen;
    public ListNode next;
    public ListNode prev;

    public ListNode(){
   
    }
    public ListNode(int data){
        this.elemen= data;
        this.next = null;
        this.prev = null;
    }
    public ListNode(int data, ListNode next, ListNode prev){
        this.elemen= data;
        this.next = next;
        this.prev = prev;
    }
    public int getElemen() {
        return elemen;
    }
    public ListNode getNext() {
        return next;
    }
    public ListNode getPrev() {
        return prev;
    }
    public void setElemen(int elemen) {
        this.elemen = elemen;
    }
    public void setNext(ListNode next) {
        this.next = next;
    }
    public void setPrev(ListNode prev) {
        this.prev = prev;
    }
}

