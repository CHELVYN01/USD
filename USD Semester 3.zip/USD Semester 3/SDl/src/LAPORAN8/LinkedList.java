/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LAPORAN8;

/**
 *
 * @author HP
 */
public class LinkedList {
    private ListNode head;
    private int size;
    
    public LinkedList(){
        head = new ListNode();
        head.next = head;
        head.prev = head;
        size = 0;
    }
    public ListNode getHead() {
        return head;
    }
    public int getSize() {
        return size;
    }
    public void setHead(ListNode head) {
        this.head = head;
    }
    public void setSize(int size) {
        this.size = size;
    }
    public void addBefore(int elemen, ListNode node){
        ListNode baru = new ListNode(elemen);  
        node.prev.next = baru;
        baru.setPrev(node.getPrev());
        baru.setNext(node);
        node.setPrev(baru);
    }
    public int remove(ListNode node){
        ListNode kiri = node.prev;
        ListNode kanan = node.next;
        kiri.next = kanan;
        kanan.prev = kiri;
        return node.elemen;
    }
    public void addFirst(int elemen){
        addBefore(elemen, head.next);
    }
    public void addLast(int elemen){
        addBefore(elemen, head);
    }
    public int removeFirst(){
        return remove(head.next);
    }
    public int removeLast(){
        return remove(head.prev);
    }
    public int search(int elemen){
        if (head == null) {
            return -1;
        }
        int index = 0;
        ListNode temp = head;
  
        while (temp != null) {
            if (temp.elemen == elemen) {
                System.out.print("Data ditemukan :");
                return elemen;
            }
           
            index++;
            temp = temp.next;
        }
        // Returns -1 if the element is not found
        return -1;
    }
    public boolean isEmpty(){
       if (size == 0){
           return true;
       } else {
           return false;
       }
    }
    public void print() {
        ListNode item = head.next;
        
        if (item == head) {
            System.out.println("Data Kosong!");
        } else {
            while (item != head) {
                System.out.print("{"+item.elemen+"}");
                item = item.getNext();
            }
            System.out.println();
        }
    }
}