/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LAPORAN8;

/**
 *
 * @author HP
 */
public class Uji_Coba {
    public static void main(String[] args) {
        LinkedList link = new LinkedList();
        
        link.addFirst(8);
        System.out.print("Tambah 8 diawal : ");
        link.print();
        
        link.addFirst(15);
        System.out.print("Tambah 15 diawal : ");
        link.print();
        
        link.addLast(26);
        System.out.print("Tambah 26 diakhir : ");
        link.print();
        
        link.addLast(14);
        System.out.print("Tambah 14 diakhir : ");
        link.print();
        
        System.out.println(link.search(5));
        
        link.removeLast();
        System.out.print("Hilangkan data diakhir : ");
        link.print();
        
        link.removeLast();
        System.out.print("Hilangkan data diakhir : ");
        link.print();
        
        link.removeFirst();
        System.out.print("Hilangkan data diawal : ");
        link.print();
        
        link.removeFirst();
        System.out.println("Hilangkan data diawal : ");
        link.print();
    }
    
}