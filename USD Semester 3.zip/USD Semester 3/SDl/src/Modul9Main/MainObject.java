package Modul9Main;
import Modul9ObjectStatis.Mahasiswa;
import Modul9ObjectStatis.Stack;

public class MainObject {

    public static void main(String[] args) {

        Stack tumpukan = new Stack(5);

        Mahasiswa mhs1 = new Mahasiswa(10001, "Zorro", "Wakil kapten", "Paingan");
        tumpukan.Push(mhs1);
        Mahasiswa mhs2 = new Mahasiswa(10002, "Luffy", "Kapten", "Seturan");
        tumpukan.Push(mhs2);
        Mahasiswa mhs3 = new Mahasiswa(10003, "Sanji", "Koki kapal", "Concat");
        tumpukan.Push(mhs3);
        Mahasiswa mhs4 = new Mahasiswa(10004, "Nami", "Navigator", "Pugeran");
        tumpukan.Push(mhs4);
        Mahasiswa mhs5 = new Mahasiswa(10005, "Niko Robin", "Arkeologi", "Tajem");
        tumpukan.Push(mhs5);
        System.out.println("Data terhapus : " + tumpukan.Pop());
        System.out.println("Data terhapus : " + tumpukan.Pop());
        System.out.println("Data terhapus : " + tumpukan.Pop());
        System.out.println("Data Tersisa : ");
        tumpukan.cetak();
     
        
    }

}
