package Modul9Main;

import Modul9Statis.Stack;

public class MainStack {

    public static void main(String[] args) {

        Stack tumpukan = new Stack(7);
        tumpukan.Push(26);
        tumpukan.cetak();
        tumpukan.Push(15);
        tumpukan.cetak();
        tumpukan.Push(8);
        tumpukan.cetak();
        tumpukan.Push(14);
        tumpukan.cetak();
        System.out.println("Data terhapus : "+tumpukan.Pop());
        System.out.println("Data terhapus : "+tumpukan.Pop());
    }

}
