
package tugas1;

public class ujiCoba {
    public static void main(String[] args) {
		MyArray kv = new MyArray(10);
		System.out.println("Tambah Depan 'A' ");
		kv.addFront('A');
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Tambah Depan 'X' ");
		kv.addFront('X');
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Tambah Belakang 'K' ");
		kv.addRear('K');
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Tambah Belakang 'Y' ");
		kv.addRear('Y');
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Tambah 'N' di index 2");
		kv.insertAt(2, 'N');
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Hapus Depan");
		kv.delFront();
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Hapus Belakang");
		kv.delRear();
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Hapus Index 1");
		kv.delAt(1);
		System.out.print("Hasil ");
		kv.print();
		
		System.out.println();
		System.out.println();
		System.out.println("Cari 'Z'");
		System.out.println("Hasil " + kv.searchData('Z'));
		
		System.out.println();
		System.out.println();
		System.out.println("Cari 'K'");
		System.out.println("Hasil " + kv.searchData('K'));
		
		System.out.println();
		System.out.println();
		System.out.println("Ambil Data index 0");
		System.out.println("Hasil " + kv.getData(0));
	}
}


