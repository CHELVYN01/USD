

package tugas1;

public class MyArray {
	private char[] data;
	private int rear = -1;

	public MyArray(int max) {
		data = new char[max];
	}

	public boolean isEmpty() {
		if (rear == -1) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isFull() {
		if (rear == data.length - 1) {
			return true;
		} else {
			return false;
		}
	}

	public int getSize() {
		return rear + 1;
	}

	public char getData(int index) {
		return data[index];
	}

	public boolean searchData(char value) {
		for (int i = 0; i <= rear; i++) {
			if (data[i] == value) {
				return true;
			}
		}
		return false;
	}

	public void addRear(char value) {
		if (isFull()) {
			System.out.println("MyArray Penuh");
		} else {
			rear++;
			data[rear] = value;
		}
	}

	public char delRear() {
		char dataReturn = 0;
		if (isEmpty()) {
			return dataReturn;
		} else {
			dataReturn = data[rear];
			rear--;
			return dataReturn;
		}
	}

	public void addFront(char value) {
		if (isFull()) {
			System.out.println("MyArray Penuh");
		} else {
			rear++;
			if (!isEmpty()) {
				for (int i = rear; i > 0;) {
					data[i] = data[--i];
				}
			}
			data[0] = value;
		}
	}

	public char delFront() {
		char dataReturn = 0;
		if (isEmpty()) {
			return dataReturn;
		} else {
			dataReturn = data[0];
			for (int i = 0; i < rear;) {
				data[i] = data[++i];
			}
			rear--;
			return dataReturn;
		}
	}

	public void insertAt(int index, char value) {
		if (isFull()) {
			System.out.println("MyArray Penuh");
		} else {
			rear++;
			if (!isEmpty()) {
				for (int i = rear; i > index;) {
					data[i] = data[--i];
				}
			}
			data[index] = value;
		}
	}

	public char delAt(int index) {
		char dataReturn = 0;
		if (isEmpty()) {
			return dataReturn;
		} else {
			dataReturn = data[index];
			for (int i = index; i < rear;) {
				data[i] = data[++i];
			}
			rear--;
			return dataReturn;
		}
	}

	public void print() {
		for (int i = 0; i <= rear; i++) {
			System.out.print(data[i] + ", ");
		}
	}
}
