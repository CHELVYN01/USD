package LAPORAN7;
public class Main {

    public static void main(String[] args) {
        LinkedList k = new LinkedList();
        k.addFirst(8); // Tambahkan data 8
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang ditambahkan
        k.addFirst(15); //Tambahkan data 15 diawal senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang ditambahkan
        k.addLast(26); //Tambahkan data 26 di akhir senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang ditambahkan
        k.addLast(14); // Tambahkan data 14 di akhir senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang ditambahkan
        k.removeLast(); //hapus data di posisi akhir senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang sudah removeLast
        k.removeLast(); //hapus data di posisi akhir senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang sudah removeLast
        k.removeFirst(); //hapus data di posisi awal senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang sudah removeFirst
        k.removeFirst(); //hapus data di posisi awal senarai
        System.out.print("Data Senarai : ");
        k.tampil();//mencetak data yang sudah removeFirst
    }
}
