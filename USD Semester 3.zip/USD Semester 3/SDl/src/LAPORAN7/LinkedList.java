package LAPORAN7;

public class LinkedList {

    private ListNode firstNode;
    private ListNode lastNode;
    private String nama;

    public LinkedList() { //Algoritma A
        firstNode = null;
        lastNode = null;
    }

    public LinkedList(String nama) {
        this.nama = nama;
    }

    public void addFirst(int data) {
        ListNode baru = new ListNode(data);
        if (isEmpty()) { //Algoritma B
            firstNode = baru;
            lastNode = baru;
        } else {//Algoritma C
            baru.setNext(firstNode);
            firstNode = baru;
        }
    }

    public void addLast(int data) {
        ListNode baru = new ListNode(data);
        if (isEmpty()) {//Algoritma B
            firstNode = baru;
            lastNode = baru;
        } else {//Algoritma D
            lastNode.setNext(baru);
            lastNode = baru;
        }
    }

    public ListNode removeFirst() {
        ListNode bantu;
        if (!isEmpty()) {
            if (firstNode == lastNode) {
                // Algoritma G
                bantu = firstNode;
                lastNode = firstNode = null;
                return bantu;
            } else { // Algoritma E
                bantu = firstNode;
                firstNode = firstNode.getNext();
                return bantu;
            }
        } else {
            return null;
        }
    }

    public ListNode removeLast() {
        ListNode bantu;
        if (!isEmpty()) {
            if (firstNode == lastNode) {
                // Algoritma G
                bantu = firstNode;
                lastNode = firstNode = null;
                return bantu;
            } else { // Algoritma F
                bantu = firstNode;
                while (bantu.getNext() != lastNode) {
                    bantu = bantu.getNext();
                }
                lastNode = bantu;
                bantu = bantu.getNext();
                lastNode.setNext(null);
                return bantu;
            }
        } else {
            return null;
        }
    }

    public boolean isEmpty() {
        if (firstNode == null) {
            return true;
        } else {
            return false;
        }
    }

    public void tampil() {
        ListNode bantu = firstNode;
        while (bantu != null) {
            System.out.print(bantu.getData() + " ");
            bantu = bantu.next;
        }
        System.out.println("");
    }
}
