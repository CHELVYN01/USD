package Modul9ObjectDinamis;

public class Stack {

    LinkedList tumpukan;

    public Stack() {
        tumpukan = new LinkedList();
    }

    public void Push(Object elemen) {
        tumpukan.addFirst((Mahasiswa)elemen);
    }

    public Object Pop() {
        return tumpukan.removeFirst();
    }

    public int size() {
        return tumpukan.getSize();
    }

    public boolean isEmpty() {
        return tumpukan.isEmpty();
    }
   
    
 
    public void cetak() {
        for(int i = 0 ; i<1; i++){
            tumpukan.cetak();
        }  
    }
}
