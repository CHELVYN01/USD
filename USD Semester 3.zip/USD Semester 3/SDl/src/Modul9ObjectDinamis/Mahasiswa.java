package Modul9ObjectDinamis;

public class Mahasiswa {

    private String nama, prodi, alamat;
    private int nim;

    public Mahasiswa( String nama) {
        this.nama = nama;
        
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getProdi() {
        return prodi;
    }

    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public int getNim() {
        return nim;
    }

    public void setNim(int nim) {
        this.nim = nim;
    }

    @Override
    public String toString() {
        return "\n" + "Nama \t\t: " + nama + "\nNIM\t\t: "
                + nim + "\nProdi\t\t: " + prodi + "\nAlamat\t\t: " + alamat + "\n";
    }
}
