

package LAPORAN6;


import java.util.Arrays;



public class Main {
    
    public static void main(String[] args) {
        
         int[] data ={23,56,45,12,67,86,43,66,99,25,61,5,78,76,33,63,5,8,15,20};
         System.out.println("larik sebelum di urut");
         System.out.print(Arrays.toString(data));
         
         
        
        System.out.println("\t");
        System.out.println("\t");
        System.out.println("Data sudah di urut menggunakan Quick Sort");
        Quick_Sort.latihan7(data,0 , data.length -1  );
        System.out.print(Arrays.toString(data));
    
        System.out.println("\t");
        System.out.println("\t");
        System.out.println();
        System.out.println("Data sudah di urut menggunakan Marger Sort");
        Marge_Sort.mergeSort(data, 0, data.length-1);
        System.out.println(Arrays.toString(data));  
       
    }}