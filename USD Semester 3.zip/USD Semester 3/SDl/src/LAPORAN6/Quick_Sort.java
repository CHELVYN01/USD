/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LAPORAN6;



public class Quick_Sort {
    public static void latihan7(int data[], int awal, int akhir){
        int index = quickSort(data,awal,akhir);
        
            if(awal < index - 1)
                latihan7(data,awal,index -1 );
            if(index < akhir)
                latihan7(data,index,akhir);
    }
    public static int quickSort(int x[], int awal, int akhir){
        int pivot = x [(awal + akhir)/2];
            while(awal <= akhir){
                while(x[awal] < pivot)  awal++;
                while(x[akhir] > pivot) akhir--;
                
                if(awal <= akhir){
                    int y = x[awal];
                    x[awal] = x[akhir];
                    x[akhir] = y;
                    
                    awal++;
                    akhir--;
                }
            }
        return awal;
        
    }
   
    
}
