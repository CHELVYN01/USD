

package LAPORAN3;

import java.util.Arrays;

public class coba4 {

    public static void main(String[] args) {
        int[] data ={23,56,45,12,67,86,43,66,99,25,61,5,78,76,33,63,5,8,15,20,21,15,3,14,17,50,55,52,93};
         int kunci = 100;
         int hasil;
         
         Arrays.sort(data);
         
         hasil = LARIK.BinarySerch(data, kunci);
         
         
        if (hasil == -1){
            System.out.println("data "+kunci+"tidak ditemukan");
        }
        else{
            System.out.println("data "+kunci +" ditemukan di index ke-"+hasil);
        }
    }
    }
    
