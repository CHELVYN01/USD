

package LAPORAN3;

import LAPORAN4.*;

public class LARIK {
   
    
    public static int SequentialSerch(Object data[], Object kunci){
        for (int counter = 0 ;counter<= data.length-1; counter++){
        if (((Comparable)data[counter]).compareTo(kunci) == 0){
            return counter;
        }   
           
       }
       return -1;
    }
    public static int BinarySerch(int data[] , int kunci){
        int elemen_tengah;
        int index_awal=0;
        int index_akhir=data.length-1;
        
        while(index_awal <= index_akhir){
         elemen_tengah = (index_awal + index_akhir) /2;
         if (data[elemen_tengah]== kunci){
             return elemen_tengah;
         }
         else if (data[elemen_tengah]> kunci){
             index_akhir = elemen_tengah -1;
             
         }
         else {
             index_awal = elemen_tengah + 1;
             
         }
}
return -1;
}
    
}          
        
        
        
      
    

