package LAPORAN4;

public class tugas1_1 implements Comparable
{
  private String nama;
    private int score;

    public tugas1_1(int score, String nama) {
        this.score = score;
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "Pemain{" + "Nama = " + nama + ", Score = " + score + '}';
    }

    @Override
    public int compareTo(Object o) {
        if (score == ((tugas1_1) o).getScore()) {
            return 0;
        } else if (score > ((tugas1_1) o).getScore()) {
            return 1;
        } else {
            return -1;
        }
    }
}
 
  

