package LAPORAN4;

import java.util.Arrays;

public class tugas1_main {
    public static void main(String[] args) {
        tugas1_1[] tm = new tugas1_1[6];

        tm[0] = new tugas1_1(657, "Jack");
        tm[1] = new tugas1_1(387, "Bill");
        tm[2] = new tugas1_1(799, "Max");
        tm[3] = new tugas1_1(245, "Sam");
        tm[4] = new tugas1_1(678, "Josh");
        tm[5] = new tugas1_1(498,"Wilson");
        System.out.println("List Gamer");
        tugas1_2.cetak(tm);
        
        System.out.println("");
        System.out.println("Sequential Search Object");
       
       tugas1_1 key = new tugas1_1(657, "Jack");

        int hasil = tugas1_2.sequentialObject(tm, key);

        if (hasil == -1) {
            System.out.println("Pemain : " + key.getNama() +" ,dan Score "
                               +key.getScore() + " tidak ditemukan");
        } else {
            System.out.println("Pemain : " + key.getNama() +" ,dan Score "
                               +key.getScore() + " berada pada index " + hasil);
        }

        System.out.println();
        System.out.println("Binary Search Object");
        System.out.println("");
        Arrays.sort(tm);
       
        tugas1_1 biner = new tugas1_1(799, "Max");
        hasil = tugas1_2.binaryObject(tm, biner);
        tugas1_2.cetak(tm);
        System.out.println("");
        if (hasil == -1) {
            System.out.println("Pemain : " + biner.getNama() +" ,dan Score "
                              +biner.getScore() + " tidak ditemukan");
        } else {
            System.out.println("Pemain: " + biner.getNama() +" ,dan Score "
                              +biner.getScore() + " berada pada index " + hasil);
        }
        System.out.println();
        System.out.println("Interpolasi Object");
       
        tugas1_1 inter = new tugas1_1(657, "Jack");
        hasil = tugas1_2.interpolationObject(tm, inter);
        if (hasil == -1) {
            System.out.println("Pemain : " + inter.getNama() +" ,dan Score  "
                              +inter.getScore() + " tidak ditemukan");
        } else {
            System.out.println("Pemain : " + inter.getNama() +" ,dan Score  "
                              +inter.getScore() + " berada pada index " + hasil);
        }
    }
}




