package LAPORAN4;

import java.util.Arrays;

public class tugas2_main {
    public static void main(String[] args) {
        tugas2_2[] tg = new tugas2_2[6];

        tg[0] = new tugas2_2(889448, "Jakarta Pusat");
        tg[1] = new tugas2_2(433539, "Yogyakarta");
        tg[2] = new tugas2_2(506397, "Surakarta");
        tg[3] = new tugas2_2(891467, "Bogor");
        tg[4] = new tugas2_2(2029797, "Medan");
        tg[5] = new tugas2_2(2288570,"Bandung");
        System.out.println("List Kependudukan");
        tugas2_1.cetak( tg);
        
        System.out.println("");
        System.out.println("Sequential Search Object");
       
       tugas2_2 key = new tugas2_2(889448, "Jakarta Pusat");

        int hasil = tugas2_1.sequentialObject( tg, key);

        if (hasil == -1) {
            System.out.println("Daerah : " + key.getNama() +" ,dan Jumlah Penduduk "
                               +key.getScore() + " tidak ditemukan");
        } else {
            System.out.println("Daerah : " + key.getNama() +" ,dan Jumlah Penduduk "
                               +key.getScore() + " berada pada index " + hasil);
        }

        System.out.println();
        System.out.println("Binary Search Object");
        System.out.println("");
        Arrays.sort(tg);
       
        tugas2_2 biner = new tugas2_2(889448, "Jakarta Pusat");
        hasil = tugas2_1.binaryObject(tg, biner);
        tugas2_1.cetak(tg);
        System.out.println("");
        if (hasil == -1) {
            System.out.println("Daerah : " + biner.getNama() +" ,dan Jumlah Penduduk " 
                                +biner.getScore() + " tidak ditemukan");
        } else {
            System.out.println("Daerah: " + biner.getNama() +" ,dan Jumlah Penduduk " 
                               +biner.getScore() + " berada pada index " + hasil);
        }
        System.out.println();
        System.out.println("Interpolasi Object");
       
        tugas2_2 inter = new tugas2_2(2029797, "Bandung");
        hasil = tugas2_1.interpolationObject(tg, inter);
        if (hasil == -1) {

            System.out.println("Daerah : " + inter.getNama() +" ,dan Jumlah Penduduk  "
                               +inter.getScore() + " tidak ditemukan");
        } else {
            System.out.println("Daerah : " + inter.getNama() +" ,dan Jumlah Penduduk  "
                               +inter.getScore() + " berada pada index " + hasil);
        }
    }
}


