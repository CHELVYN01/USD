package LAPORAN4;
public class tugas1_2 {
    public static void cetak(Object[] q) {
        for (int i = 0; i < q.length; i++) {
            System.out.println("Pada Index ke-" + i + " : " + q[i]);
        }
    }
    public static int sequentialObject(tugas1_1[] p, tugas1_1 key) {
        for (int i = 0; i < p.length - 1; i++) {
            if (((Comparable) p[i]).compareTo(key) == 0) {
                return i;
            }
        }
        return -1;
    }
    public static int binaryObject(tugas1_1[] p, tugas1_1 key) {
        int first = 0;
        int last = p.length;

        while (first <= last) {
            int mid = (first + last) / 2;
            if (((Comparable) p[mid]).compareTo(key) == 0) {
                return mid;
            } else {
                if (((Comparable) p[mid]).compareTo(key) == 1) {
                    last = (mid - 1);
                } else {
                    first = (mid + 1);
                }
            }
        }
        return -1;
    }

    public static int interpolationObject(tugas1_1[] p,tugas1_1 key) {
        int first = 0;
        int last = p.length - 1;
        int mid = 0;
        while (first <= last) {
            mid = first + ((((tugas1_1) key).getScore()
                    - ((tugas1_1) p[first]).getScore()) * (last - first))
                    / (((tugas1_1) p[last]).getScore()
                    - ((tugas1_1) p[first]).getScore());

            if (((Comparable) p[mid]).compareTo(key) == 0) {
                return mid;
            } else if (((Comparable) p[mid]).compareTo(key) > 0) {
                last = mid - 1;
            } else {
                first = mid + 1;
            }
        }
        return -1;
    }

}



