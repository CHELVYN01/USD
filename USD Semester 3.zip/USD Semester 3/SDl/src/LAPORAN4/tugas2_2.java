package LAPORAN4;

public class tugas2_2 implements Comparable {
private String nama;
    private int score;

    public tugas2_2 (int score, String nama) {
        this.score = score;
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "Daerah{" + "Nama = " + nama + ", Jumlah Penduduk = " + score + '}';
    }

    @Override
    public int compareTo(Object o) {
        if (score == ((tugas2_2 ) o).getScore()) {
            return 0;
        } else if (score > ((tugas2_2 ) o).getScore()) {
            return 1;
        } else {
            return -1;
        }
    }
}


    
    
