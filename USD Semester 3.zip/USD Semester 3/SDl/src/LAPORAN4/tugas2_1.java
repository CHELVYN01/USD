package LAPORAN4;

public class tugas2_1 {
    public static void cetak(Object[] q) {
        for (int i = 0; i < q.length; i++) {
            System.out.println("Pada Index ke-" + i + " : " + q[i]);
        }
    }
    public static int sequentialObject(tugas2_2[] p, tugas2_2 key) {
        for (int i = 0; i < p.length - 1; i++) {
            if (((Comparable) p[i]).compareTo(key) == 0) {
                return i;
            }
        }
        return -1;
    }
    public static int binaryObject(tugas2_2[] p, tugas2_2 key) {
        int first = 0;
        int last = p.length;

        while (first <= last) {
            int mid = (first + last) / 2;
            if (((Comparable) p[mid]).compareTo(key) == 0) {
                return mid;
            } else {
                if (((Comparable) p[mid]).compareTo(key) == 1) {
                    last = (mid - 1);
                } else {
                    first = (mid + 1);
                }
            }
        }
        return -1;
    }
    public static int interpolationObject(tugas2_2[] p, tugas2_2 key) {
        int first = 0;
        int last = p.length - 1;
        int mid = 0;
        while (first <= last) {
            mid = first + ((((tugas2_2) key).getScore()
                    - ((tugas2_2) p[first]).getScore()) * (last - first))
                    / (((tugas2_2) p[last]).getScore()
                    - ((tugas2_2) p[first]).getScore());

            if (((Comparable) p[mid]).compareTo(key) == 0) {
                return mid;
            } else if (((Comparable) p[mid]).compareTo(key) > 0) {
                last = mid - 1;
            } else {
                first = mid + 1;
            }
        }
        return -1;
    }
}


