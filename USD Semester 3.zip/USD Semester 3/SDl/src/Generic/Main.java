package Generic;

/**
 *
 * @author
 */
public class Main {
    public static void main(String[] args) {
        Stack<Mahasiswa> stack = new Stack<Mahasiswa>();
    
        stack.push(new Mahasiswa("kelvin_kleden", 205314117, "Informatika", "sunagakure"));
        stack.cetak();
    }
}
