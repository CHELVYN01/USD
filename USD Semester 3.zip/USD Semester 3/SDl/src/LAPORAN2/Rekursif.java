
package LAPORAN2;

import java.util.Scanner;

public class Rekursif {
  public static int pangkatRekursif(int x, int y) {
        if (y == 0) {
            return 1;
        } else {
            return x * pangkatRekursif(x, y - 1);
        }
    }

    public static void main(String[] args) {
        int x, y;
        int hasil;
        Scanner input = new Scanner(System.in);
        System.out.println("--Bilangan x pangkat y--");
        System.out.print("x = ");
        x = input.nextInt();
        System.out.print("y = ");
        y = input.nextInt();
        hasil = pangkatRekursif(x, y);
        System.out.println(x + " dipangkatkan " + y + " = " + hasil);
    }
}   

