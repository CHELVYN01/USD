
package LAPORAN2;

public class Prima {
   public static void main(String[] args) {
        System.out.println("Bilangan Prima: ");
        for (int i = 1; i < 10; i++) {
            if (cetakPrima(i, 2)) {
                System.out.print(i + ", ");
            }
        }
    }

    public static boolean cetakPrima(int n, int i) {
        if (n <= i) {
            return (n == i);
        }
        if (n % i == 0) {
            return false;
        }
        return cetakPrima(n, i + 1);
    }
}   

