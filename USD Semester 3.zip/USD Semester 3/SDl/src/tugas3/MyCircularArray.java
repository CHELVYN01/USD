
package tugas3;

public class MyCircularArray {
    private char[] data;
	private int rear = -1;
	private int front = -1;

	public MyCircularArray(int max) {
		data = new char[max];
	}

	public int getRear() {
		return rear;
	}

	public int getFront() {
		return front;
	}

	public boolean isEmpty() {
		return front == -1 && rear == -1 ? true : false;
	}

	public boolean isFull() {
		return inc(rear) == front ? true : false;
	}

	public int getSize() { 
		if (front == -1) {
			return 0;
		} else if (rear >= front) {
			return rear - front + 1;
		}
		return rear - front + 1 + data.length;
	}

	public char getData(int index) { 
		return data[index];
	}

	public boolean searchData(char value) { 
		for (int i = 0; i <= rear; i++) {
			if (data[i] == value) {
				return true;
			}
		}
		return false;
	}

	public void addRear(char value) { 
		if (isFull()) {
			grow();
		}
		if (front == -1) {
			front = 0;
		}
		rear = inc(rear); 
		data[rear] = value;
	}

	public char delRear() { 
		char dataReturn = 0;
		if (front == rear) {
			front = rear = -1;
			return dataReturn;
		} else {
			dataReturn = data[rear];
			rear--;
			return dataReturn;
		}
	}

	public void addFront(char value) { 

		if (isEmpty()) {
			front = 0;
			rear = inc(rear); 
			data[rear] = value; 
		} else {
			if (isFull()) {
				grow();
			}
			front--;
			
			if (front < 0) {
				front = data.length - Math.abs(front);
			}
			
			data[front] = value;
		}
	}

	public char delFront() {
		char dataReturn = 0;
		dataReturn = data[front];
		if (front == rear) {
			front = rear = -1;
		} else {
			front = inc(front);
		}
		return dataReturn;
	}

	public void insertAt(int index, char value) { // 
		if (isFull()) {
			grow();
		} else {
			rear++;
			if (!isEmpty()) {
				for (int i = rear; i > index;) {
					data[i] = data[--i];
				}
			}
			data[index] = value;
		}
	}

	public char delAt(int index) { 
		char dataReturn = 0;
		if (isEmpty()) {
			return dataReturn;
		} else {
			dataReturn = data[index];
			for (int i = index; i < rear;) {
				data[i] = data[++i];
			}
			rear--;
			return dataReturn;
		}
	}

	public void print() { 
		int i;
		for (i = front; i != rear; i = inc(i)) { 
			System.out.print(data[i] + ", ");
		}
		System.out.print(data[i] + ", ");

	}

	private void grow() { 
		char[] grow = new char[data.length * 2];
		int i = 0;
		int j = front;

		do {
			grow[i++] = data[j];
			j = inc(j);
		} while (j != front);
		front = 0;
		rear = data.length - 1;
		data = grow;
	}

	public int inc(int x) {
		return x == data.length - 1 ? 0 : x + 1;
	}

	public int dec(int x) {
		return x == 0 ? data.length : x - 1;
	}
}

