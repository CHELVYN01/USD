/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tugas3;

public class ujiCoba {
    public static void main(String[] args) {
		MyCircularArray kv = new MyCircularArray(5);
																	// print front to rear;
		
	
		kv.addRear('a');		
		kv.addFront('b');		
		kv.addFront('c');		
		kv.addRear('r');		
		kv.addFront('v');		
		kv.delRear();			
		kv.addFront('p');		
		kv.addFront('g');		
		kv.addFront('m');		
		kv.delFront();			
		kv.delRear();			
		kv.delAt(2);			
		System.out.println("front " + kv.getFront());
		System.out.println("rear " +kv.getRear());
		kv.print();
		System.out.println(kv.searchData('v'));
		System.out.println(kv.getData(9));
	}
}


