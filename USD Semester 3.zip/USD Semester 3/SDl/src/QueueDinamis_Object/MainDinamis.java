package QueueDinamis_Object;

public class MainDinamis {

    public static void main(String[] args) {
        Queue antrian = new Queue();
        antrian.enqueue(new Mahasiswa("virgy", 
                205314074, "Informatika", "Konoha"));
        antrian.enqueue(new Mahasiswa("Kelvin", 
                205314071, "Informatika", "Suna"));
        antrian.enqueue(new Mahasiswa("Kristian", 
                205314069, "Informatika", "kiri"));
       

        
        System.out.println("\nAntrian yang dikeluarkan" + 
                antrian.dequeue()); 
        System.out.println("\nAntrian yang dikeluarkan" + 
                antrian.dequeue()); 
        System.out.println("\nAntrian yang dikeluarkan" + 
                antrian.dequeue()); 
        
       
       
        antrian.cetak();
    }
}
