package QueueDinamis_Object;

import QueueDinamis_Object.ListNode;

public class LinkedList {

    private ListNode head;
    private int size;

    public LinkedList() {
        head = new ListNode();
        head.next = head;
        head.prev = head;
//        head.setPrev(head);
        size = 0;
    }

    public void addBefore(Object x, ListNode bantu) {
        ListNode baru = new ListNode(x);
        baru.next = bantu;
        baru.prev = bantu.prev;
        bantu.prev.next = baru;
        bantu.prev = baru;
        size++;
    }

    public void addFirst(Object elemen) {
        addBefore(elemen, head.next);
    }

    public void addLast(Object elemen) {
        addBefore(elemen, head);
    }

    public Object removeFirst() {
        return remove(head.next);
    }

    public Object removeLast() {
        return remove(head.prev);
    }
    
    private Object remove(ListNode bantu) {
        bantu.prev.next = bantu.next;
        bantu.next.prev = bantu.prev;
        size--;
        return bantu.elemen;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        if (head == head.next) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        String temp = "";

        ListNode bantu = head.next;
        while (bantu != head) {
            temp = temp + bantu.elemen + " ";
            bantu = bantu.next;
        }
        return temp;
    }
    public ListNode Search(Object search){
        ListNode bantu = head.next;
        while (bantu != head){
            if(((Comparable)bantu.elemen).compareTo(search) == 0){
                return bantu;
               
            }else {
                System.out.println("data tidak di temukan");
            }
            bantu = bantu.next;
        }
        return null;
    }
}
