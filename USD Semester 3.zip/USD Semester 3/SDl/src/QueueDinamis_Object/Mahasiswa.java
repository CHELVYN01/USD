package QueueDinamis_Object;


public class Mahasiswa implements Comparable{
    private String nama;
    private int nim;
    private String prodi;
    private String alamat;

    Mahasiswa() {}

    public Mahasiswa(String nama, int nim, String prodi, String alamat) {
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.alamat = alamat;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getNim() {
        return nim;
    }

    public void setNim(int nim) {
        this.nim = nim;
    }

    public String getProdi() {
        return prodi;
    }

    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    
    @Override
    public int compareTo(Object o) {
        if (nim == ((Mahasiswa)o).getNim())
            return 0;
        else if (nim > ((Mahasiswa)o).getNim())
            return 1;
        else
            return -1;
    }
    
    public String toString(){
        return  "\nNIM   : " + nim + "\nNama  : " + nama + 
                "\nProdi : " + prodi + "\nAlamat: " + alamat;
    }
}
