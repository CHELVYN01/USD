
package uassdla_205314117;

import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author kelvin
 */
public class UASSDLA_205314117 {

    public static void main(String[] args) {
     
       Stack tumpukan = new Stack();
        String aku = "blasius chelvyn kelvin kera kleden";
        for (int i =0; i< aku.length(); i++ ){
            tumpukan.push(new Character(aku.charAt(i)));
           
        }
        while (!tumpukan.empty()){
            Object elemen = tumpukan.pop();
            System.out.print(elemen);
        }
        System.out.println("");
    }
       
        
        
        
    }
    
    

