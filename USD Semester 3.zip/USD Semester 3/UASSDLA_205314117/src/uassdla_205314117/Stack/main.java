/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uassdla_205314117.Stack;

/**
 *
 * @author HP
 */
public class main {
    public static void main(String[] args) {
        String huruf = "Blasius Chelvyn kera kleden";
        String hasil = "";

        int jumlah = huruf.length();
        int jumlahHuruf = jumlah - 1;
        for (int i = 0; i < jumlah; i++) {
            hasil = hasil + huruf.charAt(jumlahHuruf);
            jumlahHuruf--;
        }
        System.out.println("Output: " + hasil);
    }
}
